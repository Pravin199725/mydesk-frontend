function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~student-student-module~teacher-teacher-module"], {
  /***/
  "./src/app/common/common.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/common/common.module.ts ***!
    \*****************************************/

  /*! exports provided: EventSectionModule */

  /***/
  function srcAppCommonCommonModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EventSectionModule", function () {
      return EventSectionModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _event_section_event_section_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./event-section/event-section.component */
    "./src/app/common/event-section/event-section.component.ts");
    /* harmony import */


    var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./home/home.component */
    "./src/app/common/home/home.component.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _mobile_header_mobile_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./mobile-header/mobile-header.component */
    "./src/app/common/mobile-header/mobile-header.component.ts");
    /* harmony import */


    var _dot_progress_bar_dot_progress_bar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./dot-progress-bar/dot-progress-bar.component */
    "./src/app/common/dot-progress-bar/dot-progress-bar.component.ts");
    /* harmony import */


    var _message_message_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./message/message.component */
    "./src/app/common/message/message.component.ts");

    var EventSectionModule = function EventSectionModule() {
      _classCallCheck(this, EventSectionModule);
    };

    EventSectionModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: EventSectionModule
    });
    EventSectionModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function EventSectionModule_Factory(t) {
        return new (t || EventSectionModule)();
      },
      imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"]]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](EventSectionModule, {
        declarations: [_event_section_event_section_component__WEBPACK_IMPORTED_MODULE_1__["EventSectionComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeCommonComponent"], _mobile_header_mobile_header_component__WEBPACK_IMPORTED_MODULE_4__["MobileHeaderComponent"], _dot_progress_bar_dot_progress_bar_component__WEBPACK_IMPORTED_MODULE_5__["DotProgressBarComponent"], _message_message_component__WEBPACK_IMPORTED_MODULE_6__["MessageComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"]],
        exports: [_event_section_event_section_component__WEBPACK_IMPORTED_MODULE_1__["EventSectionComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeCommonComponent"], _mobile_header_mobile_header_component__WEBPACK_IMPORTED_MODULE_4__["MobileHeaderComponent"], _dot_progress_bar_dot_progress_bar_component__WEBPACK_IMPORTED_MODULE_5__["DotProgressBarComponent"], _message_message_component__WEBPACK_IMPORTED_MODULE_6__["MessageComponent"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EventSectionModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          declarations: [_event_section_event_section_component__WEBPACK_IMPORTED_MODULE_1__["EventSectionComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeCommonComponent"], _mobile_header_mobile_header_component__WEBPACK_IMPORTED_MODULE_4__["MobileHeaderComponent"], _dot_progress_bar_dot_progress_bar_component__WEBPACK_IMPORTED_MODULE_5__["DotProgressBarComponent"], _message_message_component__WEBPACK_IMPORTED_MODULE_6__["MessageComponent"]],
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"]],
          exports: [_event_section_event_section_component__WEBPACK_IMPORTED_MODULE_1__["EventSectionComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeCommonComponent"], _mobile_header_mobile_header_component__WEBPACK_IMPORTED_MODULE_4__["MobileHeaderComponent"], _dot_progress_bar_dot_progress_bar_component__WEBPACK_IMPORTED_MODULE_5__["DotProgressBarComponent"], _message_message_component__WEBPACK_IMPORTED_MODULE_6__["MessageComponent"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/common/dot-progress-bar/dot-progress-bar.component.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/common/dot-progress-bar/dot-progress-bar.component.ts ***!
    \***********************************************************************/

  /*! exports provided: DotProgressBarComponent */

  /***/
  function srcAppCommonDotProgressBarDotProgressBarComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DotProgressBarComponent", function () {
      return DotProgressBarComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function DotProgressBarComponent_li_1_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "strong", 2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var weekList_r1 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](weekList_r1.status + (weekList_r1.isCurrent == true ? " current" : ""));

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](weekList_r1.week);
      }
    }

    var DotProgressBarComponent = /*#__PURE__*/function () {
      function DotProgressBarComponent() {
        _classCallCheck(this, DotProgressBarComponent);

        this.weekLists = [];
      }

      _createClass(DotProgressBarComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log(this.weekLists);
        }
      }]);

      return DotProgressBarComponent;
    }();

    DotProgressBarComponent.ɵfac = function DotProgressBarComponent_Factory(t) {
      return new (t || DotProgressBarComponent)();
    };

    DotProgressBarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DotProgressBarComponent,
      selectors: [["app-dot-progress-bar"]],
      inputs: {
        weekLists: "weekLists"
      },
      decls: 2,
      vars: 1,
      consts: [[1, "progressbar"], [3, "class", 4, "ngFor", "ngForOf"], [2, "font-size", "11px"]],
      template: function DotProgressBarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DotProgressBarComponent_li_1_Template, 3, 4, "li", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.weekLists);
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"]],
      styles: [".container[_ngcontent-%COMP%] {\n  width: 100%;\n  margin: 10px auto;\n}\n\n.progressbar[_ngcontent-%COMP%] {\n  display: flex;\n  -webkit-padding-start: 0px;\n          padding-inline-start: 0px;\n}\n\n.progressbar[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  list-style-type: none;\n  width: 25%;\n  float: left;\n  font-size: 1rem;\n  position: relative;\n  text-align: center;\n  color: #7d7d7d;\n}\n\n.progressbar[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:before {\n  width: 1.5rem;\n  position: relative;\n  height: 1.5rem;\n  content: \"\";\n  line-height: 30px;\n  border: 2px solid #7d7d7d;\n  display: block;\n  text-align: center;\n  margin: 0 auto 5px auto;\n  border-radius: 50%;\n  background-color: white;\n  z-index: 1;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.current[_ngcontent-%COMP%]::before {\n  transform: scale(1.5);\n}\n\n.progressbar[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:after {\n  width: 100%;\n  height: 2px;\n  content: \"\";\n  position: absolute;\n  background-color: #7d7d7d;\n  top: 0.6rem;\n  left: -50%;\n}\n\n.progressbar[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:first-child:after {\n  content: none;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.active[_ngcontent-%COMP%] {\n  color: green;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.active[_ngcontent-%COMP%]:before {\n  border-color: #55b776;\n  background-color: #55b776;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.active[_ngcontent-%COMP%]    + li[_ngcontent-%COMP%]:after {\n  background-color: #55b776;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.done[_ngcontent-%COMP%]:before {\n  border-color: #55b776;\n  background-color: #55b776;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.done[_ngcontent-%COMP%]    + li[_ngcontent-%COMP%]:after {\n  background-color: #55b776;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.inactive[_ngcontent-%COMP%]:before {\n  border-color: #7d7d7d;\n  background-color: #7d7d7d;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.inactive[_ngcontent-%COMP%]    + li[_ngcontent-%COMP%]:after {\n  background-color: #7d7d7d;\n}\n\n.progressbar[_ngcontent-%COMP%]   li.done[_ngcontent-%COMP%] {\n  position: relative;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL2RvdC1wcm9ncmVzcy1iYXIvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXBwXFxjb21tb25cXGRvdC1wcm9ncmVzcy1iYXJcXGRvdC1wcm9ncmVzcy1iYXIuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbW1vbi9kb3QtcHJvZ3Jlc3MtYmFyL2RvdC1wcm9ncmVzcy1iYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSwwQkFBQTtVQUFBLHlCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDRUo7O0FEQUE7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxVQUFBO0FDR0o7O0FEREE7RUFDSSxxQkFBQTtBQ0lKOztBREZBO0VBQ0ksV0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FDS0o7O0FESEE7RUFDSSxhQUFBO0FDTUo7O0FESkE7RUFDSSxZQUFBO0FDT0o7O0FETEE7RUFDSSxxQkFBQTtFQUNBLHlCQUFBO0FDUUo7O0FETkE7RUFDSSx5QkFBQTtBQ1NKOztBRFBBO0VBQ0kscUJBQUE7RUFDQSx5QkFBQTtBQ1VKOztBRFJBO0VBQ0kseUJBQUE7QUNXSjs7QURUQTtFQUNJLHFCQUFBO0VBQ0EseUJBQUE7QUNZSjs7QURWQTtFQUNJLHlCQUFBO0FDYUo7O0FEVkE7RUFDRSxrQkFBQTtBQ2FGIiwiZmlsZSI6InNyYy9hcHAvY29tbW9uL2RvdC1wcm9ncmVzcy1iYXIvZG90LXByb2dyZXNzLWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMTBweCBhdXRvOyBcbn1cblxuLnByb2dyZXNzYmFyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAwcHg7XG59XG4ucHJvZ3Jlc3NiYXIgbGkge1xuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgICB3aWR0aDogMjUlO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjN2Q3ZDdkO1xufVxuLnByb2dyZXNzYmFyIGxpOmJlZm9yZSB7XG4gICAgd2lkdGg6IDEuNXJlbTtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgaGVpZ2h0OiAxLjVyZW07XG4gICAgY29udGVudDogXCJcIjtcbiAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjN2Q3ZDdkO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDAgYXV0byA1cHggYXV0bztcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgei1pbmRleDogMTtcbn1cbi5wcm9ncmVzc2JhciBsaS5jdXJyZW50OjpiZWZvcmUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMS41KTtcbn1cbi5wcm9ncmVzc2JhciBsaTphZnRlciB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAycHg7XG4gICAgY29udGVudDogJyc7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM3ZDdkN2Q7XG4gICAgdG9wOiAwLjZyZW07XG4gICAgbGVmdDogLTUwJTtcbn1cbi5wcm9ncmVzc2JhciBsaTpmaXJzdC1jaGlsZDphZnRlciB7XG4gICAgY29udGVudDogbm9uZTtcbn1cbi5wcm9ncmVzc2JhciBsaS5hY3RpdmUge1xuICAgIGNvbG9yOiBncmVlbjtcbn1cbi5wcm9ncmVzc2JhciBsaS5hY3RpdmU6YmVmb3JlIHtcbiAgICBib3JkZXItY29sb3I6ICM1NWI3NzY7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzU1Yjc3Njtcbn1cbi5wcm9ncmVzc2JhciBsaS5hY3RpdmUgKyBsaTphZnRlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzU1Yjc3Njtcbn1cbi5wcm9ncmVzc2JhciBsaS5kb25lOmJlZm9yZSB7XG4gICAgYm9yZGVyLWNvbG9yOiAjNTViNzc2O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM1NWI3NzY7XG59XG4ucHJvZ3Jlc3NiYXIgbGkuZG9uZSArIGxpOmFmdGVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTViNzc2O1xufVxuLnByb2dyZXNzYmFyIGxpLmluYWN0aXZlOmJlZm9yZSB7XG4gICAgYm9yZGVyLWNvbG9yOiAjN2Q3ZDdkO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM3ZDdkN2Q7XG59XG4ucHJvZ3Jlc3NiYXIgbGkuaW5hY3RpdmUgKyBsaTphZnRlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzdkN2Q3ZDtcbn1cblxuLnByb2dyZXNzYmFyIGxpLmRvbmUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi8vIC5wcm9ncmVzc2JhciBsaS5kb25lOmFmdGVyIHtcbi8vICAgY29udGVudDogXCIgXCI7XG4vLyAgIGRpc3BsYXk6IGJsb2NrO1xuLy8gICB3aWR0aDogMC4zZW07XG4vLyAgIGhlaWdodDogMC42ZW07XG4vLyAgIGJvcmRlcjogc29saWQgd2hpdGU7XG4vLyAgIGJvcmRlci13aWR0aDogMCAwLjJlbSAwLjJlbSAwO1xuLy8gICBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgIGxlZnQ6IDQuMmVtO1xuLy8gICB0b3A6IDI2JTtcbi8vICAgbWFyZ2luLXRvcDogLTAuMmVtO1xuLy8gICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4vLyAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xuLy8gICB6LWluZGV4Ojk7XG4vLyAgIGJhY2tncm91bmQtY29sb3I6ICM1NWI3NzY7XG4vLyB9IiwiLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW46IDEwcHggYXV0bztcbn1cblxuLnByb2dyZXNzYmFyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDBweDtcbn1cblxuLnByb2dyZXNzYmFyIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICB3aWR0aDogMjUlO1xuICBmbG9hdDogbGVmdDtcbiAgZm9udC1zaXplOiAxcmVtO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICM3ZDdkN2Q7XG59XG5cbi5wcm9ncmVzc2JhciBsaTpiZWZvcmUge1xuICB3aWR0aDogMS41cmVtO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogMS41cmVtO1xuICBjb250ZW50OiBcIlwiO1xuICBsaW5lLWhlaWdodDogMzBweDtcbiAgYm9yZGVyOiAycHggc29saWQgIzdkN2Q3ZDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAwIGF1dG8gNXB4IGF1dG87XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIHotaW5kZXg6IDE7XG59XG5cbi5wcm9ncmVzc2JhciBsaS5jdXJyZW50OjpiZWZvcmUge1xuICB0cmFuc2Zvcm06IHNjYWxlKDEuNSk7XG59XG5cbi5wcm9ncmVzc2JhciBsaTphZnRlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDJweDtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjN2Q3ZDdkO1xuICB0b3A6IDAuNnJlbTtcbiAgbGVmdDogLTUwJTtcbn1cblxuLnByb2dyZXNzYmFyIGxpOmZpcnN0LWNoaWxkOmFmdGVyIHtcbiAgY29udGVudDogbm9uZTtcbn1cblxuLnByb2dyZXNzYmFyIGxpLmFjdGl2ZSB7XG4gIGNvbG9yOiBncmVlbjtcbn1cblxuLnByb2dyZXNzYmFyIGxpLmFjdGl2ZTpiZWZvcmUge1xuICBib3JkZXItY29sb3I6ICM1NWI3NzY7XG4gIGJhY2tncm91bmQtY29sb3I6ICM1NWI3NzY7XG59XG5cbi5wcm9ncmVzc2JhciBsaS5hY3RpdmUgKyBsaTphZnRlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM1NWI3NzY7XG59XG5cbi5wcm9ncmVzc2JhciBsaS5kb25lOmJlZm9yZSB7XG4gIGJvcmRlci1jb2xvcjogIzU1Yjc3NjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzU1Yjc3Njtcbn1cblxuLnByb2dyZXNzYmFyIGxpLmRvbmUgKyBsaTphZnRlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM1NWI3NzY7XG59XG5cbi5wcm9ncmVzc2JhciBsaS5pbmFjdGl2ZTpiZWZvcmUge1xuICBib3JkZXItY29sb3I6ICM3ZDdkN2Q7XG4gIGJhY2tncm91bmQtY29sb3I6ICM3ZDdkN2Q7XG59XG5cbi5wcm9ncmVzc2JhciBsaS5pbmFjdGl2ZSArIGxpOmFmdGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzdkN2Q3ZDtcbn1cblxuLnByb2dyZXNzYmFyIGxpLmRvbmUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59Il19 */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DotProgressBarComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-dot-progress-bar',
          templateUrl: './dot-progress-bar.component.html',
          styleUrls: ['./dot-progress-bar.component.scss']
        }]
      }], function () {
        return [];
      }, {
        weekLists: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/common/event-section/event-section.component.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/common/event-section/event-section.component.ts ***!
    \*****************************************************************/

  /*! exports provided: EventSectionComponent */

  /***/
  function srcAppCommonEventSectionEventSectionComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EventSectionComponent", function () {
      return EventSectionComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function EventSectionComponent_div_6_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "\xA0 ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h4", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Acknowlege");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var announcement_r3 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", announcement_r3.msg, " :");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Announcement from : ", announcement_r3.msg, "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Announcement Date : ", announcement_r3.date, " ", announcement_r3.month, "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Description : ", announcement_r3.des, " Change the size of the modal by adding the .modal-sm class for small modals or .modal-lg class for large modals.");
      }
    }

    function EventSectionComponent_div_15_Template(rf, ctx) {
      if (rf & 1) {
        var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventSectionComponent_div_15_Template_button_click_1_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);

          var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r5.goToLec();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "\xA0 ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "span", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var upcoming_r4 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", upcoming_r4.msg, " :");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.type);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("End Time: ", upcoming_r4.endtime, "");
      }
    }

    function EventSectionComponent_div_24_Template(rf, ctx) {
      if (rf & 1) {
        var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventSectionComponent_div_24_Template_button_click_1_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r8.goToLec();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "\xA0 ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "span", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var overdue_r7 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r7.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r7.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", overdue_r7.msg, " :");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r7.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r7.type);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("End Time: ", overdue_r7.endtime, "");
      }
    }

    var EventSectionComponent = /*#__PURE__*/function () {
      function EventSectionComponent(router) {
        _classCallCheck(this, EventSectionComponent);

        this.router = router;
        this.announcements = [{
          date: '8',
          month: 'Jan',
          msg: 'School ',
          des: ' Annual Function'
        }, {
          date: '26',
          month: 'Jan',
          msg: 'School ',
          des: ' Republic Day'
        }, {
          date: '2',
          month: 'Feb',
          msg: 'School ',
          des: ' 25 Anniversary of school'
        }, {
          date: '8',
          month: 'Jan',
          msg: 'School ',
          des: ' Annual Function'
        }];
        this.upcomings = [{
          date: '9',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }, {
          date: '10',
          month: 'Jan',
          msg: 'Marathi ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 2'
        }, {
          date: '12',
          month: 'Jan',
          msg: 'Hindi ',
          type: 'Test',
          endtime: '7:00 pm',
          des: ' Chapter 3'
        }, {
          date: '18',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '10:00 pm',
          des: ' Quadratic Equation'
        }];
        this.overdues = [{
          date: '7',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }, {
          date: '6',
          month: 'Jan',
          msg: 'Science ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 1'
        }, {
          date: '6',
          month: 'Jan',
          msg: 'Marathi ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 1'
        }, {
          date: '5',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }];
      }

      _createClass(EventSectionComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "goToLec",
        value: function goToLec() {
          this.router.navigate(["/student/lecture"]);
        }
      }]);

      return EventSectionComponent;
    }();

    EventSectionComponent.ɵfac = function EventSectionComponent_Factory(t) {
      return new (t || EventSectionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]));
    };

    EventSectionComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: EventSectionComponent,
      selectors: [["app-event-section"]],
      decls: 25,
      vars: 3,
      consts: [[1, "pt-3"], [1, "p-2", 2, "background", "white", "width", "100%", "border-radius", "5px", "max-height", "195px", "overflow-y", "auto"], [1, "d-flex", "flex-column", 2, "margin", "0px 5px"], [4, "ngFor", "ngForOf"], ["type", "button", "data-toggle", "modal", "data-target", "#myModal", 1, "btn", "btn-block", "d-flex", "m-2", "card", "flex-row", "card-desing"], [1, "d-flex", "flex-column", "annoucement-date-box"], [1, "announcment-card-body", "d-flex", "flex-row"], [2, "font-weight", "bold", "font-size", "17px"], [2, "padding-top", "3px"], ["id", "myModal", "role", "dialog", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-sm", 2, "border-radius", "10px", "margin-top", "100px"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], [1, "modal-body"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-default"], ["type", "button", 1, "btn", "btn-block", "d-flex", "m-2", "card", "flex-row", "card-desing", 3, "click"], [1, "announcment-card-body"], [1, "d-flex", "justify-content-between", 2, "font-size", "9px"], [2, "color", "#c4c4c4"], [1, "mr-3", 2, "color", "#c4c4c4"]],
      template: function EventSectionComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h1");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Announcement");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, EventSectionComponent_div_6_Template, 30, 9, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "h1");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Upcomings");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](15, EventSectionComponent_div_15_Template, 18, 6, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "h1");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "span");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Overdue");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, EventSectionComponent_div_24_Template, 18, 6, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.announcements);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.upcomings);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.overdues);
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"]],
      styles: [".text-primary1[_ngcontent-%COMP%] {\n  color: #1b2d3f;\n}\n.text-grey-dark[_ngcontent-%COMP%] {\n  color: #343a40;\n}\n.text-grey[_ngcontent-%COMP%] {\n  color: #676767;\n}\n.text-grey-light[_ngcontent-%COMP%] {\n  color: #EBECF0;\n}\n.bg-primary1[_ngcontent-%COMP%] {\n  background-color: #1b2d3f;\n}\n.bg-primary2[_ngcontent-%COMP%] {\n  background-color: #354658;\n}\n.bg-grey-dark[_ngcontent-%COMP%] {\n  background-color: #343a40;\n}\n.bg-grey[_ngcontent-%COMP%] {\n  background-color: #676767;\n}\n.bg-grey-light[_ngcontent-%COMP%] {\n  background-color: #EBECF0;\n}\nh1[_ngcontent-%COMP%] {\n  width: 100%;\n  border-bottom: 1px solid #000;\n  line-height: 0.1em;\n  margin: 10px 0 20px;\n}\nh1[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  background: #ebecf0;\n  padding: 0 15px 0 0;\n}\nh5[_ngcontent-%COMP%] {\n  margin-bottom: 0.4rem;\n  margin-top: 0.4rem;\n}\n.card-fixed[_ngcontent-%COMP%] {\n  height: 100%;\n  min-height: 45px;\n  max-height: 45px;\n  width: 100%;\n  max-width: 100px;\n  min-width: 100px;\n  margin-right: 2rem;\n}\n.card-desing[_ngcontent-%COMP%] {\n  background: #354658;\n  height: 50px;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25), 0px 2px 4px rgba(0, 0, 0, 0.14), 0px 3px 4px rgba(0, 0, 0, 0.12), 0px -2px 5px rgba(0, 0, 0, 0.2);\n}\n.announcment-card-body[_ngcontent-%COMP%] {\n  margin-top: auto;\n  margin-bottom: auto;\n  text-align: left;\n  padding-left: 10px;\n  width: 100%;\n  font-size: 14px;\n  color: white;\n}\n.annoucement-date-box[_ngcontent-%COMP%] {\n  background-color: #28BAA2;\n  font-size: 10px;\n  text-align: center;\n  padding: 5px;\n  padding-left: 12px;\n  padding-right: 12px;\n  color: white;\n}\n.p-2[_ngcontent-%COMP%] {\n  margin-top: 38px;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25), 0px 2px 4px rgba(0, 0, 0, 0.14), 0px 3px 4px rgba(0, 0, 0, 0.12), 0px -2px 5px rgba(0, 0, 0, 0.2);\n}\n[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 8px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  box-shadow: inset 0 0 5px grey;\n  border-radius: 10px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  background: #354658;\n  border-radius: 10px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover {\n  background: #8d8d8d;\n}\n.modal-content[_ngcontent-%COMP%] {\n  border-radius: 12px;\n}\n.modal-header[_ngcontent-%COMP%] {\n  text-align: center;\n  background-color: #1B2D3F;\n  color: #ffffff;\n  border-radius: 10px 10px 0px 0px;\n}\n.modal-title[_ngcontent-%COMP%] {\n  margin: auto;\n}\n.modal-footer[_ngcontent-%COMP%] {\n  border: none;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  text-align: center;\n  background-color: #354658;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL2V2ZW50LXNlY3Rpb24vQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfbWl4aW4uc2NzcyIsInNyYy9hcHAvY29tbW9uL2V2ZW50LXNlY3Rpb24vQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfY29sb3JzLnNjc3MiLCJzcmMvYXBwL2NvbW1vbi9ldmVudC1zZWN0aW9uL0M6XFxVc2Vyc1xcUHJhdmluXFxGcm9udC1lbmQtbWFpbi9zcmNcXGFzc2V0c1xcc2Fzc1xcYmFzZVxcX3ZhcmlhYmxlcy5zY3NzIiwic3JjL2FwcC9jb21tb24vZXZlbnQtc2VjdGlvbi9ldmVudC1zZWN0aW9uLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21tb24vZXZlbnQtc2VjdGlvbi9DOlxcVXNlcnNcXFByYXZpblxcRnJvbnQtZW5kLW1haW4vc3JjXFxhcHBcXGNvbW1vblxcZXZlbnQtc2VjdGlvblxcZXZlbnQtc2VjdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTs7Ozs7Ozs7Q0FBQTtBQVdBOzs7Ozs7Ozs7O0NBQUE7QUNYSTtFQUNJLGNDRlM7QUNvQmpCO0FGaEJJO0VBQ0ksY0NEVTtBQ21CbEI7QUZoQkk7RUFDSSxjQ0xLO0FDdUJiO0FGaEJJO0VBQ0ksY0NMVztBQ3VCbkI7QUZaSTtFQUNJLHlCQ2xCUztBQ2lDakI7QUZiSTtFQUNJLHlCQ3BCUztBQ21DakI7QUZiSTtFQUNJLHlCQ3BCVTtBQ21DbEI7QUZiSTtFQUNJLHlCQ3hCSztBQ3VDYjtBRmJJO0VBQ0kseUJDeEJXO0FDdUNuQjtBQzFDQTtFQUNJLFdBQUE7RUFFQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUQ0Q0o7QUN6Q0E7RUFFSSxtQkFBQTtFQUNBLG1CQUFBO0FEMkNKO0FDeENBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtBRDJDSjtBQ3hDQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRDJDSjtBQ3hDQTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLDhJQUFBO0FEMkNKO0FDeENBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUQyQ0o7QUN6Q0E7RUFDSSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBRDRDSjtBQzFDQTtFQUNJLGdCQUFBO0VBQ0EsOElBQUE7QUQ2Q0o7QUMzQ0E7RUFDSSxVQUFBO0FEOENKO0FDM0NFLFVBQUE7QUFDQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUQ4Q0o7QUMzQ0UsV0FBQTtBQUNBO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtBRDhDSjtBQzNDRSxvQkFBQTtBQUNBO0VBQ0UsbUJBQUE7QUQ4Q0o7QUM1Q0U7RUFDRSxtQkFBQTtBRCtDSjtBQzdDRTtFQUNJLGtCQUFBO0VBQW9CLHlCQUFBO0VBQTJCLGNBQUE7RUFBZ0IsZ0NBQUE7QURtRHJFO0FDakRFO0VBQ0UsWUFBQTtBRG9ESjtBQ2xERTtFQUNFLFlBQUE7QURxREo7QUNuREU7RUFDRSxrQkFBQTtFQUFvQix5QkFBQTtFQUEyQixjQUFBO0FEd0RuRCIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi9ldmVudC1zZWN0aW9uL2V2ZW50LXNlY3Rpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi8vIE1FRElBIFFVRVJZIE1BTkFHRVJcblxuLypcbjBweCAtIDM2MHB4Olx0XHRYUyBQaG9uZVxuMzYwcHggLSA1NzZweDogXHRcdFBob25lXG41NzZweCAtIDc2OHB4OiBcdFx0VGFibGV0IFBvcnRyYWl0XG43NjhweCAtIDk5MnB4Olx0XHRUYWJsZXQgTGFuZHNjYXBlXG45OTJweCAtIDEyMDBweDogXHRkZXNrdG9wXG4xMjAwcHggLSAxOTIwcHg6XHRub3JtYWwgTWVkaWEgcXVlcmllc1xuMTkyMHB4IGFuZCB1cDogIFx0RnVsbCBIRFxuKi9cblxuXG4vKlxuJGJyZWFrcG9pbnQgYXJndWVtZW50IGNob2ljZXM6XG4tIHhzLXBob25lXG4tIHBob25lXG4tIHRhYi1wb3J0XG4tIHRhYi1sYW5kXG4tIGRlc2t0b3Bcbi0gZnVsbC1oZFxuXG4xZW0gPSAxNnB4XG4qL1xuXG5AbWl4aW4gcmVzcG9uZE1heCgkYnJlYWtwb2ludCkge1xuXHRAaWYgJGJyZWFrcG9pbnQgPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1heC13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuICB9XG4gIEBpZiAkYnJlYWtwb2ludCA9PSBoZC1kZXNrdG9wIHtcbiAgICBAbWVkaWEgKG1heC13aWR0aDogOTBlbSkgeyBAY29udGVudCB9OyAvLzE0NDBweFxuICB9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5AbWl4aW4gcmVzcG9uZE1pbigkYnJlYWtwb2ludG1pbikge1xuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5cblxuXG4kcmVtLWJhc2VsaW5lOiAxNnB4ICFkZWZhdWx0O1xuJHJlbS1mYWxsYmFjazogZmFsc2UgIWRlZmF1bHQ7XG4kcmVtLXB4LW9ubHk6IGZhbHNlICFkZWZhdWx0O1xuXG5AZnVuY3Rpb24gcmVtLXNlcGFyYXRvcigkbGlzdCwgJHNlcGFyYXRvcjogZmFsc2UpIHtcbiAgQGlmICRzZXBhcmF0b3IgPT0gXCJjb21tYVwiIG9yICRzZXBhcmF0b3IgPT0gXCJzcGFjZVwiIHtcbiAgICBAcmV0dXJuIGFwcGVuZCgkbGlzdCwgbnVsbCwgJHNlcGFyYXRvcik7XG4gIH0gXG4gIFxuICBAaWYgZnVuY3Rpb24tZXhpc3RzKFwibGlzdC1zZXBhcmF0b3JcIikgPT0gdHJ1ZSB7XG4gICAgQHJldHVybiBsaXN0LXNlcGFyYXRvcigkbGlzdCk7XG4gIH1cblxuICAvLyBsaXN0LXNlcGFyYXRvciBwb2x5ZmlsbCBieSBIdWdvIEdpcmF1ZGVsIChodHRwczovL3Nhc3MtY29tcGF0aWJpbGl0eS5naXRodWIuaW8vI2xpc3Rfc2VwYXJhdG9yX2Z1bmN0aW9uKVxuICAkdGVzdC1saXN0OiAoKTtcbiAgQGVhY2ggJGl0ZW0gaW4gJGxpc3Qge1xuICAgICR0ZXN0LWxpc3Q6IGFwcGVuZCgkdGVzdC1saXN0LCAkaXRlbSwgc3BhY2UpO1xuICB9XG5cbiAgQHJldHVybiBpZigkdGVzdC1saXN0ID09ICRsaXN0LCBzcGFjZSwgY29tbWEpO1xufVxuXG5AbWl4aW4gcmVtLWJhc2VsaW5lKCR6b29tOiAxMDAlKSB7XG4gIGZvbnQtc2l6ZTogJHpvb20gLyAxNnB4ICogJHJlbS1iYXNlbGluZTtcbn1cblxuQGZ1bmN0aW9uIHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlcy4uLikge1xuICAkcmVzdWx0OiAoKTtcbiAgJHNlcGFyYXRvcjogcmVtLXNlcGFyYXRvcigkdmFsdWVzKTtcbiAgXG4gIEBlYWNoICR2YWx1ZSBpbiAkdmFsdWVzIHtcbiAgICBAaWYgdHlwZS1vZigkdmFsdWUpID09IFwibnVtYmVyXCIgYW5kIHVuaXQoJHZhbHVlKSA9PSBcInJlbVwiIGFuZCAkdG8gPT0gXCJweFwiIHtcbiAgICAgICRyZXN1bHQ6IGFwcGVuZCgkcmVzdWx0LCAkdmFsdWUgLyAxcmVtICogJHJlbS1iYXNlbGluZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSBpZiB0eXBlLW9mKCR2YWx1ZSkgPT0gXCJudW1iZXJcIiBhbmQgdW5pdCgkdmFsdWUpID09IFwicHhcIiBhbmQgJHRvID09IFwicmVtXCIge1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSAvICRyZW0tYmFzZWxpbmUgKiAxcmVtLCAkc2VwYXJhdG9yKTtcbiAgICB9IEBlbHNlIGlmIHR5cGUtb2YoJHZhbHVlKSA9PSBcImxpc3RcIiB7XG4gICAgICAkdmFsdWUtc2VwYXJhdG9yOiByZW0tc2VwYXJhdG9yKCR2YWx1ZSk7XG4gICAgICAkdmFsdWU6IHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlLi4uKTtcbiAgICAgICR2YWx1ZTogcmVtLXNlcGFyYXRvcigkdmFsdWUsICR2YWx1ZS1zZXBhcmF0b3IpO1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSB7XG4gICAgICAkcmVzdWx0OiBhcHBlbmQoJHJlc3VsdCwgJHZhbHVlLCAkc2VwYXJhdG9yKTtcbiAgICB9XG4gIH1cblxuICBAcmV0dXJuIGlmKGxlbmd0aCgkcmVzdWx0KSA9PSAxLCBudGgoJHJlc3VsdCwgMSksICRyZXN1bHQpO1xufVxuXG5AZnVuY3Rpb24gcmVtKCR2YWx1ZXMuLi4pIHtcbiAgQGlmICRyZW0tcHgtb25seSB7XG4gICAgQHJldHVybiByZW0tY29udmVydChweCwgJHZhbHVlcy4uLik7XG4gIH0gQGVsc2Uge1xuICAgIEByZXR1cm4gcmVtLWNvbnZlcnQocmVtLCAkdmFsdWVzLi4uKTtcbiAgfVxufVxuXG5AbWl4aW4gcmVtKCRwcm9wZXJ0aWVzLCAkdmFsdWVzLi4uKSB7XG4gIEBpZiB0eXBlLW9mKCRwcm9wZXJ0aWVzKSA9PSBcIm1hcFwiIHtcbiAgICBAZWFjaCAkcHJvcGVydHkgaW4gbWFwLWtleXMoJHByb3BlcnRpZXMpIHtcbiAgICAgIEBpbmNsdWRlIHJlbSgkcHJvcGVydHksIG1hcC1nZXQoJHByb3BlcnRpZXMsICRwcm9wZXJ0eSkpO1xuICAgIH1cbiAgfSBAZWxzZSB7XG4gICAgQGVhY2ggJHByb3BlcnR5IGluICRwcm9wZXJ0aWVzIHtcbiAgICAgIEBpZiAkcmVtLWZhbGxiYWNrIG9yICRyZW0tcHgtb25seSB7XG4gICAgICAgICN7JHByb3BlcnR5fTogcmVtLWNvbnZlcnQocHgsICR2YWx1ZXMuLi4pO1xuICAgICAgfVxuICAgICAgQGlmIG5vdCAkcmVtLXB4LW9ubHkge1xuICAgICAgICAjeyRwcm9wZXJ0eX06IHJlbS1jb252ZXJ0KHJlbSwgJHZhbHVlcy4uLik7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cblxuQG1peGluIGNvbnRlbnQtY2VudGVyIHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHRsZWZ0OiA1MCU7XG5cdHRvcDogNTAlO1xuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSkgdHJhbnNsYXRlWCgtNTAlKTtcbn0iLCJAaW1wb3J0IFwiLi4vYmFzZS92YXJpYWJsZXNcIjtcblxuLnRleHQge1xuICAgICYtcHJpbWFyeTEge1xuICAgICAgICBjb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1kYXJrO1xuICAgIH1cbiAgICAmLWdyZXkge1xuICAgICAgICBjb2xvcjogJGNvbG9yLWdyZXk7XG4gICAgfVxuICAgICYtZ3JleS1saWdodCB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG4gICBcbn1cblxuLmJnIHtcbiAgICAmLXByaW1hcnkxIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLXByaW1hcnkyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkyO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5LWRhcms7XG4gICAgfVxuICAgICYtZ3JleSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5O1xuICAgIH1cbiAgICAmLWdyZXktbGlnaHQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG59IiwiLy8gQ29sb3JzXG5cbiRjb2xvci1wcmltYXJ5MTogcmdiYSgyNyw0NSw2MywxKTtcbiRjb2xvci1wcmltYXJ5MjogcmdiYSg1Myw3MCw4OCwxKTtcblxuJGNvbG9yLWdyZXk6IHJnYmEoMTAzLCAxMDMsIDEwMywgMSk7XG4kY29sb3ItZ3JleS1kYXJrOiByZ2JhKDUyLCA1OCwgNjQsIDEpO1xuXG4kY29sb3ItZ3JleS1saWdodDogI0VCRUNGMDtcblxuJGNvbG9yLXN1Y2Nlc3M6IHJnYmEoODIsIDIwOSwgMTQ1LCAxKTtcbiRjb2xvci1lcnJvcjogcmdiYSgyMzQsIDg1LCA4NSwgMSk7XG5cbi8vIEZvbnRzXG5cbiR0aGluOiAxMDA7XG4kZXh0cmEtbGlnaHQ6IDIwMDtcbiRsaWdodDogMzAwO1xuJHJlZ3VsYXItNDAwOiA0MDA7XG4kbWVkaXVtOiA1MDA7XG4kc2VtaS1ib2xkOiA2MDA7XG4kYm9sZDogNzAwO1xuJGV4dHJhLWJvbGQ6IDgwMDtcbiRibGFjay05MDA6IDkwMDsiLCIvKlxuMHB4IC0gMzYwcHg6XHRcdFhTIFBob25lXG4zNjBweCAtIDU3NnB4OiBcdFx0UGhvbmVcbjU3NnB4IC0gNzY4cHg6IFx0XHRUYWJsZXQgUG9ydHJhaXRcbjc2OHB4IC0gOTkycHg6XHRcdFRhYmxldCBMYW5kc2NhcGVcbjk5MnB4IC0gMTIwMHB4OiBcdGRlc2t0b3BcbjEyMDBweCAtIDE5MjBweDpcdG5vcm1hbCBNZWRpYSBxdWVyaWVzXG4xOTIwcHggYW5kIHVwOiAgXHRGdWxsIEhEXG4qL1xuLypcbiRicmVha3BvaW50IGFyZ3VlbWVudCBjaG9pY2VzOlxuLSB4cy1waG9uZVxuLSBwaG9uZVxuLSB0YWItcG9ydFxuLSB0YWItbGFuZFxuLSBkZXNrdG9wXG4tIGZ1bGwtaGRcblxuMWVtID0gMTZweFxuKi9cbi50ZXh0LXByaW1hcnkxIHtcbiAgY29sb3I6ICMxYjJkM2Y7XG59XG4udGV4dC1ncmV5LWRhcmsge1xuICBjb2xvcjogIzM0M2E0MDtcbn1cbi50ZXh0LWdyZXkge1xuICBjb2xvcjogIzY3Njc2Nztcbn1cbi50ZXh0LWdyZXktbGlnaHQge1xuICBjb2xvcjogI0VCRUNGMDtcbn1cblxuLmJnLXByaW1hcnkxIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFiMmQzZjtcbn1cbi5iZy1wcmltYXJ5MiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzNTQ2NTg7XG59XG4uYmctZ3JleS1kYXJrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM0M2E0MDtcbn1cbi5iZy1ncmV5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY3Njc2Nztcbn1cbi5iZy1ncmV5LWxpZ2h0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0VCRUNGMDtcbn1cblxuaDEge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG4gIGxpbmUtaGVpZ2h0OiAwLjFlbTtcbiAgbWFyZ2luOiAxMHB4IDAgMjBweDtcbn1cblxuaDEgc3BhbiB7XG4gIGJhY2tncm91bmQ6ICNlYmVjZjA7XG4gIHBhZGRpbmc6IDAgMTVweCAwIDA7XG59XG5cbmg1IHtcbiAgbWFyZ2luLWJvdHRvbTogMC40cmVtO1xuICBtYXJnaW4tdG9wOiAwLjRyZW07XG59XG5cbi5jYXJkLWZpeGVkIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBtaW4taGVpZ2h0OiA0NXB4O1xuICBtYXgtaGVpZ2h0OiA0NXB4O1xuICB3aWR0aDogMTAwJTtcbiAgbWF4LXdpZHRoOiAxMDBweDtcbiAgbWluLXdpZHRoOiAxMDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAycmVtO1xufVxuXG4uY2FyZC1kZXNpbmcge1xuICBiYWNrZ3JvdW5kOiAjMzU0NjU4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJveC1zaGFkb3c6IDBweCA0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yNSksIDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xNCksIDBweCAzcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xMiksIDBweCAtMnB4IDVweCByZ2JhKDAsIDAsIDAsIDAuMik7XG59XG5cbi5hbm5vdW5jbWVudC1jYXJkLWJvZHkge1xuICBtYXJnaW4tdG9wOiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmFubm91Y2VtZW50LWRhdGUtYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI4QkFBMjtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbiAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5wLTIge1xuICBtYXJnaW4tdG9wOiAzOHB4O1xuICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpLCAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTQpLCAwcHggM3B4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTIpLCAwcHggLTJweCA1cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufVxuXG46Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDhweDtcbn1cblxuLyogVHJhY2sgKi9cbjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xuICBib3gtc2hhZG93OiBpbnNldCAwIDAgNXB4IGdyZXk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi8qIEhhbmRsZSAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XG4gIGJhY2tncm91bmQ6ICMzNTQ2NTg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi8qIEhhbmRsZSBvbiBob3ZlciAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICM4ZDhkOGQ7XG59XG5cbi5tb2RhbC1jb250ZW50IHtcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcbn1cblxuLm1vZGFsLWhlYWRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFCMkQzRjtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMHB4O1xufVxuXG4ubW9kYWwtdGl0bGUge1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5tb2RhbC1mb290ZXIge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5tb2RhbC1mb290ZXIgLmJ0biB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM1NDY1ODtcbiAgY29sb3I6ICNmZmZmZmY7XG59IiwiQGltcG9ydCBcIi4uLy4uLy4uL2Fzc2V0cy9zYXNzL2Jhc2UvbWl4aW5cIjtcbkBpbXBvcnQgXCIuLi8uLi8uLi9hc3NldHMvc2Fzcy9iYXNlL2NvbG9yc1wiO1xuXG5cblxuaDEge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vIHRleHQtYWxpZ246IGNlbnRlcjsgXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG4gICAgbGluZS1oZWlnaHQ6IDAuMWVtO1xuICAgIG1hcmdpbjogMTBweCAwIDIwcHg7XG59XG5cbmgxIHNwYW4ge1xuICAgIC8vIHotaW5kZXg6IDEwMDtcbiAgICBiYWNrZ3JvdW5kOiAjZWJlY2YwO1xuICAgIHBhZGRpbmc6IDAgMTVweCAwIDA7XG59XG5cbmg1IHtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjRyZW07XG4gICAgbWFyZ2luLXRvcDogMC40cmVtO1xufVxuXG4uY2FyZC1maXhlZCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1pbi1oZWlnaHQ6IDQ1cHg7XG4gICAgbWF4LWhlaWdodDogNDVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXgtd2lkdGg6IDEwMHB4O1xuICAgIG1pbi13aWR0aDogMTAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAycmVtO1xufVxuXG4uY2FyZC1kZXNpbmcge1xuICAgIGJhY2tncm91bmQ6ICMzNTQ2NTg7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIGJveC1zaGFkb3c6IDBweCA0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yNSksIDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xNCksIDBweCAzcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xMiksIDBweCAtMnB4IDVweCByZ2JhKDAsIDAsIDAsIDAuMik7XG59XG5cbi5hbm5vdW5jbWVudC1jYXJkLWJvZHkge1xuICAgIG1hcmdpbi10b3A6IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogYXV0bztcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuLmFubm91Y2VtZW50LWRhdGUtYm94IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjhCQUEyO1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTJweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cbi5wLTJ7XG4gICAgbWFyZ2luLXRvcDogMzhweDtcbiAgICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpLCAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTQpLCAwcHggM3B4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTIpLCAwcHggLTJweCA1cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufVxuOjotd2Via2l0LXNjcm9sbGJhciB7XG4gICAgd2lkdGg6IDhweDtcbiAgfVxuICBcbiAgLyogVHJhY2sgKi9cbiAgOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDVweCBncmV5OyBcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB9XG4gICBcbiAgLyogSGFuZGxlICovXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICAgIGJhY2tncm91bmQ6ICMzNTQ2NTg7IFxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIH1cbiAgXG4gIC8qIEhhbmRsZSBvbiBob3ZlciAqL1xuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjOGQ4ZDhkOyBcbiAgfVxuICAubW9kYWwtY29udGVudHtcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICB9XG4gIC5tb2RhbC1oZWFkZXJ7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IGJhY2tncm91bmQtY29sb3I6ICMxQjJEM0Y7IGNvbG9yOiAjZmZmZmZmOyBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgICB9XG4gIC5tb2RhbC10aXRsZXtcbiAgICBtYXJnaW46IGF1dG87XG4gIH1cbiAgLm1vZGFsLWZvb3RlcntcbiAgICBib3JkZXI6IG5vbmU7XG4gIH1cbiAgLm1vZGFsLWZvb3RlciAuYnRue1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgYmFja2dyb3VuZC1jb2xvcjogIzM1NDY1ODsgY29sb3I6ICNmZmZmZmY7XG4gIH0iXX0= */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EventSectionComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-event-section',
          templateUrl: './event-section.component.html',
          styleUrls: ['./event-section.component.scss']
        }]
      }], function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/common/home/home.component.ts":
  /*!***********************************************!*\
    !*** ./src/app/common/home/home.component.ts ***!
    \***********************************************/

  /*! exports provided: HomeCommonComponent */

  /***/
  function srcAppCommonHomeHomeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeCommonComponent", function () {
      return HomeCommonComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_services_mobileView_mobile_view_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/mobileView/mobile-view.service */
    "./src/app/services/mobileView/mobile-view.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _event_section_event_section_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../event-section/event-section.component */
    "./src/app/common/event-section/event-section.component.ts");

    function HomeCommonComponent_div_6_span_3_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var subject_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](subject_r2["class"]);
      }
    }

    function HomeCommonComponent_div_6_button_6_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "+");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function HomeCommonComponent_div_6_button_7_Template(rf, ctx) {
      if (rf & 1) {
        var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeCommonComponent_div_6_button_7_Template_button_click_0_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r8.goToCourse();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Go to Course");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function HomeCommonComponent_div_6_button_8_Template(rf, ctx) {
      if (rf & 1) {
        var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeCommonComponent_div_6_button_8_Template_button_click_0_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);

          var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r10.goToCourse();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Go to Course");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function HomeCommonComponent_div_6_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, HomeCommonComponent_div_6_span_3_Template, 2, 1, "span", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, HomeCommonComponent_div_6_button_6_Template, 2, 0, "button", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, HomeCommonComponent_div_6_button_7_Template, 3, 0, "button", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, HomeCommonComponent_div_6_button_8_Template, 3, 0, "button", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "hr", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var subject_r2 = ctx.$implicit;

        var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.type == "teacher");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](subject_r2.subjectName);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.type == "teacher");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.isMobileView);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.isMobileView);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Teacher name: ", subject_r2.teacherName, " ");
      }
    }

    function HomeCommonComponent_div_7_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-event-section");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    var HomeCommonComponent = /*#__PURE__*/function () {
      function HomeCommonComponent(router, responsiveService, zone) {
        _classCallCheck(this, HomeCommonComponent);

        this.router = router;
        this.responsiveService = responsiveService;
        this.zone = zone;
        this.type = 'student';
        this.subjectData = [{
          subjectName: 'Computer',
          "class": '10th B',
          teacherName: 'M Patil'
        }, {
          subjectName: 'English',
          "class": '10th B',
          teacherName: 'Mr Kale'
        }, {
          subjectName: 'Marathi',
          "class": '10th B',
          teacherName: 'Mr Pravin',
          studenLength: '50',
          subjectCode: 'ASWS32'
        }, {
          subjectName: 'Science',
          "class": '10th B',
          teacherName: 'Mr arsh'
        }, {
          subjectName: 'History',
          "class": '10th B',
          teacherName: 'Mr Animesh'
        }, {
          subjectName: 'Geography',
          "class": '10th B',
          teacherName: 'Mr prashant'
        }, {
          subjectName: 'Hindi',
          "class": '10th B',
          teacherName: 'Mrs Patil'
        }];
      }

      _createClass(HomeCommonComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.onResize();
          this.responsiveService.checkWidth();
        }
      }, {
        key: "onResize",
        value: function onResize() {
          var _this = this;

          this.responsiveService.getMobileStatus().subscribe(function (isMobile) {
            _this.zone.run(function () {
              _this.isMobileView = isMobile;
            });
          });
        }
      }, {
        key: "goToCourse",
        value: function goToCourse() {
          this.router.navigate(["/".concat(this.type, "/course")]);
        }
      }]);

      return HomeCommonComponent;
    }();

    HomeCommonComponent.ɵfac = function HomeCommonComponent_Factory(t) {
      return new (t || HomeCommonComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_mobileView_mobile_view_service__WEBPACK_IMPORTED_MODULE_2__["MobileViewService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]));
    };

    HomeCommonComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: HomeCommonComponent,
      selectors: [["app-common-home"]],
      inputs: {
        type: "type"
      },
      decls: 8,
      vars: 2,
      consts: [[1, "d-flex", "flex-wrap", "pt-3", 2, "padding-bottom", "80px"], [1, "col-lg-8", "col-md-8", "col-sm-12", "pt-3"], [1, "row", "m-0"], ["class", "mt-4", "style", "background: white; width: 100%;border-radius: 5px;box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25)", 4, "ngFor", "ngForOf"], ["class", "col-lg-4 col-md-4 col-sm-12", "style", "border-left: 2px solid black; padding-bottom: 50px;", 4, "ngIf"], [1, "mt-4", 2, "background", "white", "width", "100%", "border-radius", "5px", "box-shadow", "0px 4px 4px rgba(0, 0, 0, 0.25)"], [1, "d-flex", "justify-content-between", "p-2"], ["di", ""], ["style", "font-size: 2rem;", "class", "mr-3", 4, "ngIf"], [2, "font-size", "2rem", "font-weight", "bold"], ["style", "border-radius: 5px;font-size: 12px;", "class", "ml-3", 4, "ngIf"], ["style", "border-radius: 5px;background: #354658;color: white; width: 150px; height: 40px; font-size: 15px;", 3, "click", 4, "ngIf"], ["style", "border-radius: 5px;background: #354658;color: white; width: 100px; height: 25px; font-size: 12px;", 3, "click", 4, "ngIf"], [2, "margin", "0px 5px", "border-top", "1px solid lightgray", "padding-left", "1px"], [2, "font-size", "1.3rem", "color", "#757575"], [1, "mr-3", 2, "font-size", "2rem"], [1, "ml-3", 2, "border-radius", "5px", "font-size", "12px"], [2, "border-radius", "5px", "background", "#354658", "color", "white", "width", "150px", "height", "40px", "font-size", "15px", 3, "click"], [2, "border-radius", "5px", "background", "#354658", "color", "white", "width", "100px", "height", "25px", "font-size", "12px", 3, "click"], [1, "col-lg-4", "col-md-4", "col-sm-12", 2, "border-left", "2px solid black", "padding-bottom", "50px"]],
      template: function HomeCommonComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h1");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Courses");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, HomeCommonComponent_div_6_Template, 13, 6, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, HomeCommonComponent_div_7_Template, 2, 0, "div", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.subjectData);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isMobileView);
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _event_section_event_section_component__WEBPACK_IMPORTED_MODULE_4__["EventSectionComponent"]],
      styles: [".text-primary1[_ngcontent-%COMP%] {\n  color: #1b2d3f;\n}\n.text-grey-dark[_ngcontent-%COMP%] {\n  color: #343a40;\n}\n.text-grey[_ngcontent-%COMP%] {\n  color: #676767;\n}\n.text-grey-light[_ngcontent-%COMP%] {\n  color: #EBECF0;\n}\n.bg-primary1[_ngcontent-%COMP%] {\n  background-color: #1b2d3f;\n}\n.bg-primary2[_ngcontent-%COMP%] {\n  background-color: #354658;\n}\n.bg-grey-dark[_ngcontent-%COMP%] {\n  background-color: #343a40;\n}\n.bg-grey[_ngcontent-%COMP%] {\n  background-color: #676767;\n}\n.bg-grey-light[_ngcontent-%COMP%] {\n  background-color: #EBECF0;\n}\nh1[_ngcontent-%COMP%] {\n  width: 100%;\n  border-bottom: 1px solid #000;\n  line-height: 0.1em;\n  margin: 10px 0 10px;\n}\nh1[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  background: #ebecf0;\n  padding: 0 15px 0 0;\n}\nh5[_ngcontent-%COMP%] {\n  margin-bottom: 0.4rem;\n  margin-top: 0.4rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL2hvbWUvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfbWl4aW4uc2NzcyIsInNyYy9hcHAvY29tbW9uL2hvbWUvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfY29sb3JzLnNjc3MiLCJzcmMvYXBwL2NvbW1vbi9ob21lL0M6XFxVc2Vyc1xcUHJhdmluXFxGcm9udC1lbmQtbWFpbi9zcmNcXGFzc2V0c1xcc2Fzc1xcYmFzZVxcX3ZhcmlhYmxlcy5zY3NzIiwic3JjL2FwcC9jb21tb24vaG9tZS9ob21lLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21tb24vaG9tZS9DOlxcVXNlcnNcXFByYXZpblxcRnJvbnQtZW5kLW1haW4vc3JjXFxhcHBcXGNvbW1vblxcaG9tZVxcaG9tZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTs7Ozs7Ozs7Q0FBQTtBQVdBOzs7Ozs7Ozs7O0NBQUE7QUNYSTtFQUNJLGNDRlM7QUNvQmpCO0FGaEJJO0VBQ0ksY0NEVTtBQ21CbEI7QUZoQkk7RUFDSSxjQ0xLO0FDdUJiO0FGaEJJO0VBQ0ksY0NMVztBQ3VCbkI7QUZaSTtFQUNJLHlCQ2xCUztBQ2lDakI7QUZiSTtFQUNJLHlCQ3BCUztBQ21DakI7QUZiSTtFQUNJLHlCQ3BCVTtBQ21DbEI7QUZiSTtFQUNJLHlCQ3hCSztBQ3VDYjtBRmJJO0VBQ0kseUJDeEJXO0FDdUNuQjtBQzNDQTtFQUNJLFdBQUE7RUFFQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUQ2Q0o7QUMxQ0E7RUFFSSxtQkFBQTtFQUNBLG1CQUFBO0FENENKO0FDekNBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtBRDRDSiIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi9ob21lL2hvbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi8vIE1FRElBIFFVRVJZIE1BTkFHRVJcblxuLypcbjBweCAtIDM2MHB4Olx0XHRYUyBQaG9uZVxuMzYwcHggLSA1NzZweDogXHRcdFBob25lXG41NzZweCAtIDc2OHB4OiBcdFx0VGFibGV0IFBvcnRyYWl0XG43NjhweCAtIDk5MnB4Olx0XHRUYWJsZXQgTGFuZHNjYXBlXG45OTJweCAtIDEyMDBweDogXHRkZXNrdG9wXG4xMjAwcHggLSAxOTIwcHg6XHRub3JtYWwgTWVkaWEgcXVlcmllc1xuMTkyMHB4IGFuZCB1cDogIFx0RnVsbCBIRFxuKi9cblxuXG4vKlxuJGJyZWFrcG9pbnQgYXJndWVtZW50IGNob2ljZXM6XG4tIHhzLXBob25lXG4tIHBob25lXG4tIHRhYi1wb3J0XG4tIHRhYi1sYW5kXG4tIGRlc2t0b3Bcbi0gZnVsbC1oZFxuXG4xZW0gPSAxNnB4XG4qL1xuXG5AbWl4aW4gcmVzcG9uZE1heCgkYnJlYWtwb2ludCkge1xuXHRAaWYgJGJyZWFrcG9pbnQgPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1heC13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuICB9XG4gIEBpZiAkYnJlYWtwb2ludCA9PSBoZC1kZXNrdG9wIHtcbiAgICBAbWVkaWEgKG1heC13aWR0aDogOTBlbSkgeyBAY29udGVudCB9OyAvLzE0NDBweFxuICB9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5AbWl4aW4gcmVzcG9uZE1pbigkYnJlYWtwb2ludG1pbikge1xuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5cblxuXG4kcmVtLWJhc2VsaW5lOiAxNnB4ICFkZWZhdWx0O1xuJHJlbS1mYWxsYmFjazogZmFsc2UgIWRlZmF1bHQ7XG4kcmVtLXB4LW9ubHk6IGZhbHNlICFkZWZhdWx0O1xuXG5AZnVuY3Rpb24gcmVtLXNlcGFyYXRvcigkbGlzdCwgJHNlcGFyYXRvcjogZmFsc2UpIHtcbiAgQGlmICRzZXBhcmF0b3IgPT0gXCJjb21tYVwiIG9yICRzZXBhcmF0b3IgPT0gXCJzcGFjZVwiIHtcbiAgICBAcmV0dXJuIGFwcGVuZCgkbGlzdCwgbnVsbCwgJHNlcGFyYXRvcik7XG4gIH0gXG4gIFxuICBAaWYgZnVuY3Rpb24tZXhpc3RzKFwibGlzdC1zZXBhcmF0b3JcIikgPT0gdHJ1ZSB7XG4gICAgQHJldHVybiBsaXN0LXNlcGFyYXRvcigkbGlzdCk7XG4gIH1cblxuICAvLyBsaXN0LXNlcGFyYXRvciBwb2x5ZmlsbCBieSBIdWdvIEdpcmF1ZGVsIChodHRwczovL3Nhc3MtY29tcGF0aWJpbGl0eS5naXRodWIuaW8vI2xpc3Rfc2VwYXJhdG9yX2Z1bmN0aW9uKVxuICAkdGVzdC1saXN0OiAoKTtcbiAgQGVhY2ggJGl0ZW0gaW4gJGxpc3Qge1xuICAgICR0ZXN0LWxpc3Q6IGFwcGVuZCgkdGVzdC1saXN0LCAkaXRlbSwgc3BhY2UpO1xuICB9XG5cbiAgQHJldHVybiBpZigkdGVzdC1saXN0ID09ICRsaXN0LCBzcGFjZSwgY29tbWEpO1xufVxuXG5AbWl4aW4gcmVtLWJhc2VsaW5lKCR6b29tOiAxMDAlKSB7XG4gIGZvbnQtc2l6ZTogJHpvb20gLyAxNnB4ICogJHJlbS1iYXNlbGluZTtcbn1cblxuQGZ1bmN0aW9uIHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlcy4uLikge1xuICAkcmVzdWx0OiAoKTtcbiAgJHNlcGFyYXRvcjogcmVtLXNlcGFyYXRvcigkdmFsdWVzKTtcbiAgXG4gIEBlYWNoICR2YWx1ZSBpbiAkdmFsdWVzIHtcbiAgICBAaWYgdHlwZS1vZigkdmFsdWUpID09IFwibnVtYmVyXCIgYW5kIHVuaXQoJHZhbHVlKSA9PSBcInJlbVwiIGFuZCAkdG8gPT0gXCJweFwiIHtcbiAgICAgICRyZXN1bHQ6IGFwcGVuZCgkcmVzdWx0LCAkdmFsdWUgLyAxcmVtICogJHJlbS1iYXNlbGluZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSBpZiB0eXBlLW9mKCR2YWx1ZSkgPT0gXCJudW1iZXJcIiBhbmQgdW5pdCgkdmFsdWUpID09IFwicHhcIiBhbmQgJHRvID09IFwicmVtXCIge1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSAvICRyZW0tYmFzZWxpbmUgKiAxcmVtLCAkc2VwYXJhdG9yKTtcbiAgICB9IEBlbHNlIGlmIHR5cGUtb2YoJHZhbHVlKSA9PSBcImxpc3RcIiB7XG4gICAgICAkdmFsdWUtc2VwYXJhdG9yOiByZW0tc2VwYXJhdG9yKCR2YWx1ZSk7XG4gICAgICAkdmFsdWU6IHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlLi4uKTtcbiAgICAgICR2YWx1ZTogcmVtLXNlcGFyYXRvcigkdmFsdWUsICR2YWx1ZS1zZXBhcmF0b3IpO1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSB7XG4gICAgICAkcmVzdWx0OiBhcHBlbmQoJHJlc3VsdCwgJHZhbHVlLCAkc2VwYXJhdG9yKTtcbiAgICB9XG4gIH1cblxuICBAcmV0dXJuIGlmKGxlbmd0aCgkcmVzdWx0KSA9PSAxLCBudGgoJHJlc3VsdCwgMSksICRyZXN1bHQpO1xufVxuXG5AZnVuY3Rpb24gcmVtKCR2YWx1ZXMuLi4pIHtcbiAgQGlmICRyZW0tcHgtb25seSB7XG4gICAgQHJldHVybiByZW0tY29udmVydChweCwgJHZhbHVlcy4uLik7XG4gIH0gQGVsc2Uge1xuICAgIEByZXR1cm4gcmVtLWNvbnZlcnQocmVtLCAkdmFsdWVzLi4uKTtcbiAgfVxufVxuXG5AbWl4aW4gcmVtKCRwcm9wZXJ0aWVzLCAkdmFsdWVzLi4uKSB7XG4gIEBpZiB0eXBlLW9mKCRwcm9wZXJ0aWVzKSA9PSBcIm1hcFwiIHtcbiAgICBAZWFjaCAkcHJvcGVydHkgaW4gbWFwLWtleXMoJHByb3BlcnRpZXMpIHtcbiAgICAgIEBpbmNsdWRlIHJlbSgkcHJvcGVydHksIG1hcC1nZXQoJHByb3BlcnRpZXMsICRwcm9wZXJ0eSkpO1xuICAgIH1cbiAgfSBAZWxzZSB7XG4gICAgQGVhY2ggJHByb3BlcnR5IGluICRwcm9wZXJ0aWVzIHtcbiAgICAgIEBpZiAkcmVtLWZhbGxiYWNrIG9yICRyZW0tcHgtb25seSB7XG4gICAgICAgICN7JHByb3BlcnR5fTogcmVtLWNvbnZlcnQocHgsICR2YWx1ZXMuLi4pO1xuICAgICAgfVxuICAgICAgQGlmIG5vdCAkcmVtLXB4LW9ubHkge1xuICAgICAgICAjeyRwcm9wZXJ0eX06IHJlbS1jb252ZXJ0KHJlbSwgJHZhbHVlcy4uLik7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cblxuQG1peGluIGNvbnRlbnQtY2VudGVyIHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHRsZWZ0OiA1MCU7XG5cdHRvcDogNTAlO1xuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSkgdHJhbnNsYXRlWCgtNTAlKTtcbn0iLCJAaW1wb3J0IFwiLi4vYmFzZS92YXJpYWJsZXNcIjtcblxuLnRleHQge1xuICAgICYtcHJpbWFyeTEge1xuICAgICAgICBjb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1kYXJrO1xuICAgIH1cbiAgICAmLWdyZXkge1xuICAgICAgICBjb2xvcjogJGNvbG9yLWdyZXk7XG4gICAgfVxuICAgICYtZ3JleS1saWdodCB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG4gICBcbn1cblxuLmJnIHtcbiAgICAmLXByaW1hcnkxIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLXByaW1hcnkyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkyO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5LWRhcms7XG4gICAgfVxuICAgICYtZ3JleSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5O1xuICAgIH1cbiAgICAmLWdyZXktbGlnaHQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG59IiwiLy8gQ29sb3JzXG5cbiRjb2xvci1wcmltYXJ5MTogcmdiYSgyNyw0NSw2MywxKTtcbiRjb2xvci1wcmltYXJ5MjogcmdiYSg1Myw3MCw4OCwxKTtcblxuJGNvbG9yLWdyZXk6IHJnYmEoMTAzLCAxMDMsIDEwMywgMSk7XG4kY29sb3ItZ3JleS1kYXJrOiByZ2JhKDUyLCA1OCwgNjQsIDEpO1xuXG4kY29sb3ItZ3JleS1saWdodDogI0VCRUNGMDtcblxuJGNvbG9yLXN1Y2Nlc3M6IHJnYmEoODIsIDIwOSwgMTQ1LCAxKTtcbiRjb2xvci1lcnJvcjogcmdiYSgyMzQsIDg1LCA4NSwgMSk7XG5cbi8vIEZvbnRzXG5cbiR0aGluOiAxMDA7XG4kZXh0cmEtbGlnaHQ6IDIwMDtcbiRsaWdodDogMzAwO1xuJHJlZ3VsYXItNDAwOiA0MDA7XG4kbWVkaXVtOiA1MDA7XG4kc2VtaS1ib2xkOiA2MDA7XG4kYm9sZDogNzAwO1xuJGV4dHJhLWJvbGQ6IDgwMDtcbiRibGFjay05MDA6IDkwMDsiLCIvKlxuMHB4IC0gMzYwcHg6XHRcdFhTIFBob25lXG4zNjBweCAtIDU3NnB4OiBcdFx0UGhvbmVcbjU3NnB4IC0gNzY4cHg6IFx0XHRUYWJsZXQgUG9ydHJhaXRcbjc2OHB4IC0gOTkycHg6XHRcdFRhYmxldCBMYW5kc2NhcGVcbjk5MnB4IC0gMTIwMHB4OiBcdGRlc2t0b3BcbjEyMDBweCAtIDE5MjBweDpcdG5vcm1hbCBNZWRpYSBxdWVyaWVzXG4xOTIwcHggYW5kIHVwOiAgXHRGdWxsIEhEXG4qL1xuLypcbiRicmVha3BvaW50IGFyZ3VlbWVudCBjaG9pY2VzOlxuLSB4cy1waG9uZVxuLSBwaG9uZVxuLSB0YWItcG9ydFxuLSB0YWItbGFuZFxuLSBkZXNrdG9wXG4tIGZ1bGwtaGRcblxuMWVtID0gMTZweFxuKi9cbi50ZXh0LXByaW1hcnkxIHtcbiAgY29sb3I6ICMxYjJkM2Y7XG59XG4udGV4dC1ncmV5LWRhcmsge1xuICBjb2xvcjogIzM0M2E0MDtcbn1cbi50ZXh0LWdyZXkge1xuICBjb2xvcjogIzY3Njc2Nztcbn1cbi50ZXh0LWdyZXktbGlnaHQge1xuICBjb2xvcjogI0VCRUNGMDtcbn1cblxuLmJnLXByaW1hcnkxIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFiMmQzZjtcbn1cbi5iZy1wcmltYXJ5MiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzNTQ2NTg7XG59XG4uYmctZ3JleS1kYXJrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM0M2E0MDtcbn1cbi5iZy1ncmV5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY3Njc2Nztcbn1cbi5iZy1ncmV5LWxpZ2h0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0VCRUNGMDtcbn1cblxuaDEge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG4gIGxpbmUtaGVpZ2h0OiAwLjFlbTtcbiAgbWFyZ2luOiAxMHB4IDAgMTBweDtcbn1cblxuaDEgc3BhbiB7XG4gIGJhY2tncm91bmQ6ICNlYmVjZjA7XG4gIHBhZGRpbmc6IDAgMTVweCAwIDA7XG59XG5cbmg1IHtcbiAgbWFyZ2luLWJvdHRvbTogMC40cmVtO1xuICBtYXJnaW4tdG9wOiAwLjRyZW07XG59IiwiQGltcG9ydCBcIi4uLy4uLy4uL2Fzc2V0cy9zYXNzL2Jhc2UvbWl4aW5cIjtcbkBpbXBvcnQgXCIuLi8uLi8uLi9hc3NldHMvc2Fzcy9iYXNlL2NvbG9yc1wiO1xuXG5cbmgxIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7IFxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xuICAgIGxpbmUtaGVpZ2h0OiAwLjFlbTtcbiAgICBtYXJnaW46IDEwcHggMCAxMHB4O1xufVxuXG5oMSBzcGFuIHtcbiAgICAvLyB6LWluZGV4OiAxMDA7XG4gICAgYmFja2dyb3VuZDogI2ViZWNmMDtcbiAgICBwYWRkaW5nOiAwIDE1cHggMCAwO1xufVxuXG5oNSB7XG4gICAgbWFyZ2luLWJvdHRvbTogMC40cmVtO1xuICAgIG1hcmdpbi10b3A6IDAuNHJlbTtcbn1cbiJdfQ== */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeCommonComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-common-home',
          templateUrl: './home.component.html',
          styleUrls: ['./home.component.scss']
        }]
      }], function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }, {
          type: src_app_services_mobileView_mobile_view_service__WEBPACK_IMPORTED_MODULE_2__["MobileViewService"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
        }];
      }, {
        type: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/common/message/message.component.ts":
  /*!*****************************************************!*\
    !*** ./src/app/common/message/message.component.ts ***!
    \*****************************************************/

  /*! exports provided: MessageComponent */

  /***/
  function srcAppCommonMessageMessageComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MessageComponent", function () {
      return MessageComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function MessageComponent_div_0_h1_133_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Subject Teachers");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function MessageComponent_div_0_h1_134_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Student");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function MessageComponent_div_0_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](31, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](64, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](76, "How are you ? ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](80, "I am fine");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "form", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "button", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, " + ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "button", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](86, " + ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](87, "input", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "button", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](89, "i", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "button", 24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](91, "i", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 25);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div", 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](95, "img", 4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](97, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](103, "Principal");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](107, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](110, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](111, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](113, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](115, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Department head");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "div", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](123, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](126, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](127, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](129, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](131, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](133, MessageComponent_div_0_h1_133_Template, 3, 0, "h1", 0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](134, MessageComponent_div_0_h1_134_Template, 3, 0, "h1", 0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "div", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](138, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](141, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](142, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](144, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](146, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 32);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "div", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](149, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](150, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](153, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](154, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](156, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](158, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "div", 32);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "div", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](161, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](162, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](163, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](164, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](165, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](166, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](168, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](169, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](170, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"]("mesgs " + (ctx_r0.isMobileView ? "mobile" : ""));

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "msg_mobile_history" : "msg_history");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](64);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.type == "student");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.type == "teacher");
      }
    }

    function MessageComponent_div_1_div_1_h1_34_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Subject Teachers");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function MessageComponent_div_1_div_1_h1_35_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Student");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function MessageComponent_div_1_div_1_Template(rf, ctx) {
      if (rf & 1) {
        var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 34);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Principal");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_1_Template_div_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r8.openMsg();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "h1");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Department head");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_1_Template_div_click_22_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r10.openMsg();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](34, MessageComponent_div_1_div_1_h1_34_Template, 3, 0, "h1", 0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](35, MessageComponent_div_1_div_1_h1_35_Template, 3, 0, "h1", 0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_1_Template_div_click_37_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r11.openMsg();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](39, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](43, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 32);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_1_Template_div_click_49_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r12.openMsg();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](51, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](55, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 32);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_1_Template_div_click_61_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

          var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r13.openMsg();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](63, "img", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "span", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](69, "example@gmail.com");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](71, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](34);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r4.type == "student");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r4.type == "teacher");
      }
    }

    function MessageComponent_div_1_div_2_Template(rf, ctx) {
      if (rf & 1) {
        var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 36);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MessageComponent_div_1_div_2_Template_button_click_1_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15);

          var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r14.back();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " Back ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Name");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " : ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](31, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Hello");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "span", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, "T");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](64, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, "Hii ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "span", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Nirav");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "p", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](76, "How are you ? ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "div", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](80, "I am fine");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "form", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "button", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, " + ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "button", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](86, " + ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](87, "input", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "button", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](89, "i", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "button", 24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](91, "i", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"]("mesgs " + (ctx_r5.isMobileView ? "mobile" : ""));

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "msg_mobile_history" : "msg_history");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r5.isMobileView ? "incoming_msg_img_mobile d-flex" : "incoming_msg_img d-flex");
      }
    }

    function MessageComponent_div_1_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MessageComponent_div_1_div_1_Template, 72, 2, "div", 33);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, MessageComponent_div_1_div_2_Template, 92, 9, "div", 0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r1.msgView);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.msgView);
      }
    }

    var MessageComponent = /*#__PURE__*/function () {
      function MessageComponent() {
        _classCallCheck(this, MessageComponent);

        this.type = '';
        this.isMobileView = false;
        this.msgView = false;
      }

      _createClass(MessageComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "openMsg",
        value: function openMsg() {
          this.msgView = true;
        }
      }, {
        key: "back",
        value: function back() {
          this.msgView = false;
        }
      }]);

      return MessageComponent;
    }();

    MessageComponent.ɵfac = function MessageComponent_Factory(t) {
      return new (t || MessageComponent)();
    };

    MessageComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: MessageComponent,
      selectors: [["app-common-message"]],
      inputs: {
        type: "type",
        isMobileView: "isMobileView"
      },
      decls: 2,
      vars: 2,
      consts: [[4, "ngIf"], [1, "d-flex"], [1, "col-9", "p-0", "h-100", 2, "border-right", "1px solid gray"], [1, "p-3", "d-flex", "justify-content-between", 2, "background", "white", "border-bottom", "1px solid lightgray"], ["width", "50", "src", "https://i.imgur.com/k2PZLZa.png", "alt", "User avatar"], [1, "ml-3"], [1, "btn"], [3, "ngClass"], [1, "incoming_msg", "d-flex", "flex-column"], [1, "badge", "badge-secondary", "teacherBadge"], ["src", "https://i.imgur.com/k2PZLZa.png", "alt", "User avatar"], [1, "received_msg"], [1, "name"], [1, "received_withd_msg"], [1, "d-flex", "justify-content-between", 2, "background", "none"], [1, "outgoing_msg"], [1, "sent_msg"], [1, "type_msg"], [1, "input_msg_write", "d-flex"], ["type", "button", 1, "btn", 2, "background", "#05728f none repeat scroll 0 0", "border", "medium none", "border-radius", "50%", "color", "#fff", "cursor", "pointer", "font-size", "17px", "/* height", "33px", "*/\n                                /* position", "absolute", "*/\n                                /* top", "11px", "*/\n                                width", "40px", "margin", "5px"], ["type", "button", 1, "btn", 2, "background", "#05728f none repeat scroll 0 0", "border", "medium none", "border-radius", "50%", "color", "#fff", "cursor", "pointer", "font-size", "17px", "/* height", "33px", "*/\n                                /* position", "absolute", "*/\n                                /* top", "11px", "*/\n                                width", "40px", "/* left", "40px !important", "*/\n                                margin", "5px"], ["type", "text", "placeholder", "Type a message", "name", "newMessage", 1, "write_msg"], ["type", "button", 1, "msg_send_btn", 2, "right", "40px !important"], ["aria-hidden", "true", 1, "fa", "fa-paper-plane-o"], ["type", "button", 1, "msg_send_btn", "one"], [1, "col-3", "p-0"], [1, "p-4", "d-flex", "justify-content-between", 2, "background", "white", "border-bottom", "1px solid lightgray", "border-bottom-left-radius", "10px", "border-bottom-right-radius", "10px"], [1, "pt-5", 2, "padding", "5px"], [2, "background", "#95a2ad", "width", "100%", "border-radius", "5px"], [1, "d-flex", "justify-content-between", "pt-3", "pb-3", 2, "margin", "0px 5px"], ["width", "30", "src", "https://i.imgur.com/k2PZLZa.png", "alt", "User avatar"], [1, "ml-3", "fw-700", 2, "font-size", "14px"], [1, "mt-3", 2, "background", "#95a2ad", "width", "100%", "border-radius", "5px"], ["class", "p-3", 4, "ngIf"], [1, "p-3"], [1, "d-flex", "justify-content-between", "pt-3", "pb-3", 2, "margin", "0px 5px", 3, "click"], [1, "btn", "btn-primary", 3, "click"]],
      template: function MessageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, MessageComponent_div_0_Template, 171, 11, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MessageComponent_div_1_Template, 3, 2, "div", 0);
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isMobileView);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isMobileView);
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"]],
      styles: [".text-primary1[_ngcontent-%COMP%] {\n  color: #1b2d3f;\n}\n.text-grey-dark[_ngcontent-%COMP%] {\n  color: #343a40;\n}\n.text-grey[_ngcontent-%COMP%] {\n  color: #676767;\n}\n.text-grey-light[_ngcontent-%COMP%] {\n  color: #EBECF0;\n}\n.bg-primary1[_ngcontent-%COMP%] {\n  background-color: #1b2d3f;\n}\n.bg-primary2[_ngcontent-%COMP%] {\n  background-color: #354658;\n}\n.bg-grey-dark[_ngcontent-%COMP%] {\n  background-color: #343a40;\n}\n.bg-grey[_ngcontent-%COMP%] {\n  background-color: #676767;\n}\n.bg-grey-light[_ngcontent-%COMP%] {\n  background-color: #EBECF0;\n}\nh1[_ngcontent-%COMP%] {\n  width: 100%;\n  border-bottom: 1px solid #000;\n  line-height: 0.1em;\n  margin: 10px 0 20px;\n}\nh1[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  background: #ebecf0;\n  padding: 0 15px 0 0;\n}\nh5[_ngcontent-%COMP%] {\n  margin-bottom: 0.4rem;\n  margin-top: 0.4rem;\n}\nimg[_ngcontent-%COMP%] {\n  max-width: 100%;\n}\n.inbox_people[_ngcontent-%COMP%] {\n  background: #f8f8f8 none repeat scroll 0 0;\n  float: left;\n  overflow: hidden;\n  width: 40%;\n  border-right: 1px solid #c4c4c4;\n}\n.inbox_msg[_ngcontent-%COMP%] {\n  border: 1px solid #c4c4c4;\n  clear: both;\n  overflow: hidden;\n}\n.top_spac[_ngcontent-%COMP%] {\n  margin: 20px 0 0;\n}\n.channel_heading[_ngcontent-%COMP%] {\n  float: left;\n  width: 40%;\n}\n.srch_bar[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-align: right;\n  width: 60%;\n}\n.headind_srch[_ngcontent-%COMP%] {\n  padding: 10px 29px 10px 20px;\n  overflow: hidden;\n  border-bottom: 1px solid #c4c4c4;\n}\n.channel_heading[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  color: #05728f;\n  font-size: 21px;\n  margin: auto;\n}\n.srch_bar[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  border: 1px solid #cdcdcd;\n  border-width: 0 0 1px 0;\n  width: 80%;\n  padding: 2px 0 4px 6px;\n  background: none;\n}\n.srch_bar[_ngcontent-%COMP%]   .input-group-addon[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  padding: 0;\n  color: #707070;\n  font-size: 18px;\n}\n.srch_bar[_ngcontent-%COMP%]   .input-group-addon[_ngcontent-%COMP%] {\n  margin: 0 0 0 -27px;\n}\n.chat_ib[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 15px;\n  color: #464646;\n  margin: 0 0 8px 0;\n}\n.chat_ib[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 13px;\n  float: right;\n}\n.chat_ib[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #989898;\n  margin: auto;\n}\n.chat_img[_ngcontent-%COMP%] {\n  float: left;\n  width: 11%;\n}\n.chat_ib[_ngcontent-%COMP%] {\n  float: left;\n  padding: 0 0 0 15px;\n  width: 88%;\n}\n.chat_people[_ngcontent-%COMP%] {\n  overflow: hidden;\n  clear: both;\n}\n.chat_list[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #c4c4c4;\n  margin: 0;\n  padding: 18px 16px 10px;\n}\n.inbox_chat[_ngcontent-%COMP%] {\n  height: 550px;\n  overflow-y: scroll;\n}\n.active_chat[_ngcontent-%COMP%] {\n  background: #ebebeb;\n}\n.incoming_msg_img[_ngcontent-%COMP%] {\n  margin-bottom: 5px;\n  background: #ffebeb;\n  width: 50%;\n  position: relative;\n  border-radius: 10px;\n  margin-top: 5px;\n}\n.incoming_msg_img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 3rem;\n  height: 3rem;\n  align-self: center;\n  margin-left: 5px;\n}\n.incoming_msg_img[_ngcontent-%COMP%]   .name[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  margin: 0px;\n}\n.incoming_msg_img_mobile[_ngcontent-%COMP%] {\n  background: #ffebeb;\n  width: 50%;\n  position: relative;\n  border-radius: 10px;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.incoming_msg_img_mobile[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 3rem;\n  height: 3rem;\n  align-self: center;\n  margin-left: 5px;\n}\n.teacherBadge[_ngcontent-%COMP%] {\n  right: 0;\n  position: absolute !important;\n  top: -5px !important;\n  font-size: 12px;\n  z-index: auto;\n}\n.received_msg[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 0 0 0 10px;\n  vertical-align: top;\n  width: 92%;\n}\n.received_withd_msg[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  background: #ebebeb none repeat scroll 0 0;\n  border-radius: 3px;\n  color: #646464;\n  font-size: 14px;\n  margin: 0;\n  padding: 0;\n  width: 100%;\n}\n.time_date[_ngcontent-%COMP%] {\n  color: #747474;\n  display: block;\n  font-size: 12px;\n  margin: 8px 0 0;\n}\n.received_withd_msg[_ngcontent-%COMP%] {\n  width: 45%;\n}\n.mesgs[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.sent_msg[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  background: #05728f none repeat scroll 0 0;\n  border-radius: 3px;\n  font-size: 14px;\n  margin: 0;\n  color: #fff;\n  padding: 5px 10px 5px 12px;\n  width: 100%;\n}\n.outgoing_msg[_ngcontent-%COMP%] {\n  overflow: hidden;\n  margin: 26px 0 26px;\n}\n.sent_msg[_ngcontent-%COMP%] {\n  float: right;\n  width: 46%;\n}\n.input_msg_write[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  color: #4c4c4c;\n  font-size: 15px;\n  min-height: 50px;\n  width: 100%;\n}\n.type_msg[_ngcontent-%COMP%] {\n  border-top: 1px solid #c4c4c4;\n  bottom: 0;\n  width: 100%;\n  background: white;\n}\n.msg_send_btn[_ngcontent-%COMP%] {\n  background: #05728f none repeat scroll 0 0;\n  border: medium none;\n  border-radius: 50%;\n  color: #fff;\n  cursor: pointer;\n  font-size: 17px;\n  margin: 5px;\n  width: 40px;\n}\n@media (max-width: 660px) {\n  .msg_send_btn[_ngcontent-%COMP%] {\n    left: 88%;\n  }\n}\n@media (max-width: 660px) {\n  .msg_send_btn.one[_ngcontent-%COMP%] {\n    left: 78%;\n  }\n}\n.messaging[_ngcontent-%COMP%] {\n  padding: 0 0 50px 0;\n}\n.msg_history[_ngcontent-%COMP%] {\n  height: 605px;\n  overflow-y: auto;\n  padding-left: 15px;\n  padding-right: 15px;\n  margin-top: 10px;\n}\n.msg_mobile_history[_ngcontent-%COMP%] {\n  height: 100%;\n  overflow-y: auto;\n}\n.mobile[_ngcontent-%COMP%] {\n  padding-left: 0;\n  padding-right: 0;\n}\n.mobile[_ngcontent-%COMP%]   .msg_mobile_history[_ngcontent-%COMP%] {\n  padding-left: 10px;\n  padding-right: 10px;\n  margin-top: 15px;\n}\n.mobile[_ngcontent-%COMP%]   .type_msg[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 65px;\n  width: 100%;\n  background: white;\n  z-index: 100;\n}\n.message[_ngcontent-%COMP%] {\n  list-style-type: none;\n}\n.badge[_ngcontent-%COMP%] {\n  top: -1.5rem;\n  position: relative;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL21lc3NhZ2UvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfbWl4aW4uc2NzcyIsInNyYy9hcHAvY29tbW9uL21lc3NhZ2UvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfY29sb3JzLnNjc3MiLCJzcmMvYXBwL2NvbW1vbi9tZXNzYWdlL0M6XFxVc2Vyc1xcUHJhdmluXFxGcm9udC1lbmQtbWFpbi9zcmNcXGFzc2V0c1xcc2Fzc1xcYmFzZVxcX3ZhcmlhYmxlcy5zY3NzIiwic3JjL2FwcC9jb21tb24vbWVzc2FnZS9tZXNzYWdlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21tb24vbWVzc2FnZS9DOlxcVXNlcnNcXFByYXZpblxcRnJvbnQtZW5kLW1haW4vc3JjXFxhcHBcXGNvbW1vblxcbWVzc2FnZVxcbWVzc2FnZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTs7Ozs7Ozs7Q0FBQTtBQVdBOzs7Ozs7Ozs7O0NBQUE7QUNYSTtFQUNJLGNDRlM7QUNvQmpCO0FGaEJJO0VBQ0ksY0NEVTtBQ21CbEI7QUZoQkk7RUFDSSxjQ0xLO0FDdUJiO0FGaEJJO0VBQ0ksY0NMVztBQ3VCbkI7QUZaSTtFQUNJLHlCQ2xCUztBQ2lDakI7QUZiSTtFQUNJLHlCQ3BCUztBQ21DakI7QUZiSTtFQUNJLHlCQ3BCVTtBQ21DbEI7QUZiSTtFQUNJLHlCQ3hCSztBQ3VDYjtBRmJJO0VBQ0kseUJDeEJXO0FDdUNuQjtBQzVDQTtFQUNFLFdBQUE7RUFFQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUQ4Q0Y7QUMzQ0E7RUFFRSxtQkFBQTtFQUNBLG1CQUFBO0FENkNGO0FDMUNBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtBRDZDRjtBQzFDQTtFQUNFLGVBQUE7QUQ2Q0Y7QUMxQ0E7RUFDRSwwQ0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSwrQkFBQTtBRDZDRjtBQzFDQTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FENkNGO0FDMUNBO0VBQ0UsZ0JBQUE7QUQ2Q0Y7QUMxQ0E7RUFDRSxXQUFBO0VBQ0EsVUFBQTtBRDZDRjtBQzFDQTtFQUNFLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FENkNGO0FDMUNBO0VBQ0UsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGdDQUFBO0FENkNGO0FDMUNBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FENkNGO0FDMUNBO0VBQ0UseUJBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FENkNGO0FDMUNBO0VBQ0UsbURBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBRDZDRjtBQzFDQTtFQUNFLG1CQUFBO0FENkNGO0FDMUNBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBRDZDRjtBQzFDQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FENkNGO0FDMUNBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FENkNGO0FDMUNBO0VBQ0UsV0FBQTtFQUNBLFVBQUE7QUQ2Q0Y7QUMxQ0E7RUFDRSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0FENkNGO0FDMUNBO0VBQ0UsZ0JBQUE7RUFDQSxXQUFBO0FENkNGO0FDMUNBO0VBQ0UsZ0NBQUE7RUFDQSxTQUFBO0VBQ0EsdUJBQUE7QUQ2Q0Y7QUMxQ0E7RUFDRSxhQUFBO0VBQ0Esa0JBQUE7QUQ2Q0Y7QUMxQ0E7RUFDRSxtQkFBQTtBRDZDRjtBQzFDQTtFQUdFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUQyQ0Y7QUMxQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUQ0Q0o7QUMxQ0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FENENKO0FDeENBO0VBR0UsbUJBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBRHlDRjtBQ3ZDRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBRHlDSjtBQ3JDQTtFQUNFLFFBQUE7RUFDQSw2QkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7QUR3Q0Y7QUNyQ0E7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0FEd0NGO0FDaENBO0VBQ0UsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FEbUNGO0FDaENBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBRG1DRjtBQ2hDQTtFQUNFLFVBQUE7QURtQ0Y7QUNoQ0E7RUFDRSxXQUFBO0FEbUNGO0FDaENBO0VBQ0UsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLDBCQUFBO0VBQ0EsV0FBQTtBRG1DRjtBQ2hDQTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7QURtQ0Y7QUNoQ0E7RUFDRSxZQUFBO0VBQ0EsVUFBQTtBRG1DRjtBQ2hDQTtFQUNFLG1EQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBRG1DRjtBQ2hDQTtFQUNFLDZCQUFBO0VBRUEsU0FBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBRGtDRjtBQy9CQTtFQUNFLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUtBLFdBQUE7RUFDQSxXQUFBO0FEOEJGO0FDN0JFO0VBYkY7SUFjSSxTQUFBO0VEZ0NGO0FBQ0Y7QUM3Qkk7RUFGRjtJQUdJLFNBQUE7RURnQ0o7QUFDRjtBQzVCQTtFQUNFLG1CQUFBO0FEK0JGO0FDNUJBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FEK0JGO0FDNUJBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FEK0JGO0FDNUJBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FEK0JGO0FDOUJFO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FEZ0NKO0FDOUJFO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FEZ0NKO0FDNUJBO0VBQ0UscUJBQUE7QUQrQkY7QUM1QkE7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7QUQrQkYiLCJmaWxlIjoic3JjL2FwcC9jb21tb24vbWVzc2FnZS9tZXNzYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4vLyBNRURJQSBRVUVSWSBNQU5BR0VSXG5cbi8qXG4wcHggLSAzNjBweDpcdFx0WFMgUGhvbmVcbjM2MHB4IC0gNTc2cHg6IFx0XHRQaG9uZVxuNTc2cHggLSA3NjhweDogXHRcdFRhYmxldCBQb3J0cmFpdFxuNzY4cHggLSA5OTJweDpcdFx0VGFibGV0IExhbmRzY2FwZVxuOTkycHggLSAxMjAwcHg6IFx0ZGVza3RvcFxuMTIwMHB4IC0gMTkyMHB4Olx0bm9ybWFsIE1lZGlhIHF1ZXJpZXNcbjE5MjBweCBhbmQgdXA6ICBcdEZ1bGwgSERcbiovXG5cblxuLypcbiRicmVha3BvaW50IGFyZ3VlbWVudCBjaG9pY2VzOlxuLSB4cy1waG9uZVxuLSBwaG9uZVxuLSB0YWItcG9ydFxuLSB0YWItbGFuZFxuLSBkZXNrdG9wXG4tIGZ1bGwtaGRcblxuMWVtID0gMTZweFxuKi9cblxuQG1peGluIHJlc3BvbmRNYXgoJGJyZWFrcG9pbnQpIHtcblx0QGlmICRicmVha3BvaW50ID09IHhzLXBob25lIHtcblx0XHRAbWVkaWEgKG1heC13aWR0aDogMjIuNWVtKSB7IEBjb250ZW50IH07IC8vMzYwcHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gc20tcGhvbmUge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiAzNmVtKSB7IEBjb250ZW50IH07IC8vNTc2cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gbWQtdGFiIHtcblx0XHRAbWVkaWEgKG1heC13aWR0aDogNDhlbSkgeyBAY29udGVudCB9OyAvLzc2OHB4XG5cdH1cblx0QGlmICRicmVha3BvaW50ID09IGxnLWRlc2t0b3Age1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiA2MmVtKSB7IEBjb250ZW50IH07IC8vOTkycHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0geGwtZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDc1ZW0pIHsgQGNvbnRlbnQgfTsgLy8xMjAwcHhcbiAgfVxuICBAaWYgJGJyZWFrcG9pbnQgPT0gaGQtZGVza3RvcCB7XG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDkwZW0pIHsgQGNvbnRlbnQgfTsgLy8xNDQwcHhcbiAgfVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gZnVsbC1oZCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDEyMGVtKSB7IEBjb250ZW50IH07IC8vMTkyMHB4XG5cdH1cbn1cblxuQG1peGluIHJlc3BvbmRNaW4oJGJyZWFrcG9pbnRtaW4pIHtcblx0QGlmICRicmVha3BvaW50bWluID09IHhzLXBob25lIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMjIuNWVtKSB7IEBjb250ZW50IH07IC8vMzYwcHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gc20tcGhvbmUge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiAzNmVtKSB7IEBjb250ZW50IH07IC8vNTc2cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gbWQtdGFiIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogNDhlbSkgeyBAY29udGVudCB9OyAvLzc2OHB4XG5cdH1cblx0QGlmICRicmVha3BvaW50bWluID09IGxnLWRlc2t0b3Age1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiA2MmVtKSB7IEBjb250ZW50IH07IC8vOTkycHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0geGwtZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDc1ZW0pIHsgQGNvbnRlbnQgfTsgLy8xMjAwcHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gZnVsbC1oZCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDEyMGVtKSB7IEBjb250ZW50IH07IC8vMTkyMHB4XG5cdH1cbn1cblxuXG5cblxuJHJlbS1iYXNlbGluZTogMTZweCAhZGVmYXVsdDtcbiRyZW0tZmFsbGJhY2s6IGZhbHNlICFkZWZhdWx0O1xuJHJlbS1weC1vbmx5OiBmYWxzZSAhZGVmYXVsdDtcblxuQGZ1bmN0aW9uIHJlbS1zZXBhcmF0b3IoJGxpc3QsICRzZXBhcmF0b3I6IGZhbHNlKSB7XG4gIEBpZiAkc2VwYXJhdG9yID09IFwiY29tbWFcIiBvciAkc2VwYXJhdG9yID09IFwic3BhY2VcIiB7XG4gICAgQHJldHVybiBhcHBlbmQoJGxpc3QsIG51bGwsICRzZXBhcmF0b3IpO1xuICB9IFxuICBcbiAgQGlmIGZ1bmN0aW9uLWV4aXN0cyhcImxpc3Qtc2VwYXJhdG9yXCIpID09IHRydWUge1xuICAgIEByZXR1cm4gbGlzdC1zZXBhcmF0b3IoJGxpc3QpO1xuICB9XG5cbiAgLy8gbGlzdC1zZXBhcmF0b3IgcG9seWZpbGwgYnkgSHVnbyBHaXJhdWRlbCAoaHR0cHM6Ly9zYXNzLWNvbXBhdGliaWxpdHkuZ2l0aHViLmlvLyNsaXN0X3NlcGFyYXRvcl9mdW5jdGlvbilcbiAgJHRlc3QtbGlzdDogKCk7XG4gIEBlYWNoICRpdGVtIGluICRsaXN0IHtcbiAgICAkdGVzdC1saXN0OiBhcHBlbmQoJHRlc3QtbGlzdCwgJGl0ZW0sIHNwYWNlKTtcbiAgfVxuXG4gIEByZXR1cm4gaWYoJHRlc3QtbGlzdCA9PSAkbGlzdCwgc3BhY2UsIGNvbW1hKTtcbn1cblxuQG1peGluIHJlbS1iYXNlbGluZSgkem9vbTogMTAwJSkge1xuICBmb250LXNpemU6ICR6b29tIC8gMTZweCAqICRyZW0tYmFzZWxpbmU7XG59XG5cbkBmdW5jdGlvbiByZW0tY29udmVydCgkdG8sICR2YWx1ZXMuLi4pIHtcbiAgJHJlc3VsdDogKCk7XG4gICRzZXBhcmF0b3I6IHJlbS1zZXBhcmF0b3IoJHZhbHVlcyk7XG4gIFxuICBAZWFjaCAkdmFsdWUgaW4gJHZhbHVlcyB7XG4gICAgQGlmIHR5cGUtb2YoJHZhbHVlKSA9PSBcIm51bWJlclwiIGFuZCB1bml0KCR2YWx1ZSkgPT0gXCJyZW1cIiBhbmQgJHRvID09IFwicHhcIiB7XG4gICAgICAkcmVzdWx0OiBhcHBlbmQoJHJlc3VsdCwgJHZhbHVlIC8gMXJlbSAqICRyZW0tYmFzZWxpbmUsICRzZXBhcmF0b3IpO1xuICAgIH0gQGVsc2UgaWYgdHlwZS1vZigkdmFsdWUpID09IFwibnVtYmVyXCIgYW5kIHVuaXQoJHZhbHVlKSA9PSBcInB4XCIgYW5kICR0byA9PSBcInJlbVwiIHtcbiAgICAgICRyZXN1bHQ6IGFwcGVuZCgkcmVzdWx0LCAkdmFsdWUgLyAkcmVtLWJhc2VsaW5lICogMXJlbSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSBpZiB0eXBlLW9mKCR2YWx1ZSkgPT0gXCJsaXN0XCIge1xuICAgICAgJHZhbHVlLXNlcGFyYXRvcjogcmVtLXNlcGFyYXRvcigkdmFsdWUpO1xuICAgICAgJHZhbHVlOiByZW0tY29udmVydCgkdG8sICR2YWx1ZS4uLik7XG4gICAgICAkdmFsdWU6IHJlbS1zZXBhcmF0b3IoJHZhbHVlLCAkdmFsdWUtc2VwYXJhdG9yKTtcbiAgICAgICRyZXN1bHQ6IGFwcGVuZCgkcmVzdWx0LCAkdmFsdWUsICRzZXBhcmF0b3IpO1xuICAgIH0gQGVsc2Uge1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSwgJHNlcGFyYXRvcik7XG4gICAgfVxuICB9XG5cbiAgQHJldHVybiBpZihsZW5ndGgoJHJlc3VsdCkgPT0gMSwgbnRoKCRyZXN1bHQsIDEpLCAkcmVzdWx0KTtcbn1cblxuQGZ1bmN0aW9uIHJlbSgkdmFsdWVzLi4uKSB7XG4gIEBpZiAkcmVtLXB4LW9ubHkge1xuICAgIEByZXR1cm4gcmVtLWNvbnZlcnQocHgsICR2YWx1ZXMuLi4pO1xuICB9IEBlbHNlIHtcbiAgICBAcmV0dXJuIHJlbS1jb252ZXJ0KHJlbSwgJHZhbHVlcy4uLik7XG4gIH1cbn1cblxuQG1peGluIHJlbSgkcHJvcGVydGllcywgJHZhbHVlcy4uLikge1xuICBAaWYgdHlwZS1vZigkcHJvcGVydGllcykgPT0gXCJtYXBcIiB7XG4gICAgQGVhY2ggJHByb3BlcnR5IGluIG1hcC1rZXlzKCRwcm9wZXJ0aWVzKSB7XG4gICAgICBAaW5jbHVkZSByZW0oJHByb3BlcnR5LCBtYXAtZ2V0KCRwcm9wZXJ0aWVzLCAkcHJvcGVydHkpKTtcbiAgICB9XG4gIH0gQGVsc2Uge1xuICAgIEBlYWNoICRwcm9wZXJ0eSBpbiAkcHJvcGVydGllcyB7XG4gICAgICBAaWYgJHJlbS1mYWxsYmFjayBvciAkcmVtLXB4LW9ubHkge1xuICAgICAgICAjeyRwcm9wZXJ0eX06IHJlbS1jb252ZXJ0KHB4LCAkdmFsdWVzLi4uKTtcbiAgICAgIH1cbiAgICAgIEBpZiBub3QgJHJlbS1weC1vbmx5IHtcbiAgICAgICAgI3skcHJvcGVydHl9OiByZW0tY29udmVydChyZW0sICR2YWx1ZXMuLi4pO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5cbkBtaXhpbiBjb250ZW50LWNlbnRlciB7XG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0bGVmdDogNTAlO1xuXHR0b3A6IDUwJTtcblx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpIHRyYW5zbGF0ZVgoLTUwJSk7XG59IiwiQGltcG9ydCBcIi4uL2Jhc2UvdmFyaWFibGVzXCI7XG5cbi50ZXh0IHtcbiAgICAmLXByaW1hcnkxIHtcbiAgICAgICAgY29sb3I6ICRjb2xvci1wcmltYXJ5MTtcbiAgICB9XG4gICAgJi1ncmV5LWRhcmsge1xuICAgICAgICBjb2xvcjogJGNvbG9yLWdyZXktZGFyaztcbiAgICB9XG4gICAgJi1ncmV5IHtcbiAgICAgICAgY29sb3I6ICRjb2xvci1ncmV5O1xuICAgIH1cbiAgICAmLWdyZXktbGlnaHQge1xuICAgICAgICBjb2xvcjogJGNvbG9yLWdyZXktbGlnaHQ7XG4gICAgfVxuICAgXG59XG5cbi5iZyB7XG4gICAgJi1wcmltYXJ5MSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1wcmltYXJ5MTtcbiAgICB9XG4gICAgJi1wcmltYXJ5MiB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1wcmltYXJ5MjtcbiAgICB9XG4gICAgJi1ncmV5LWRhcmsge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItZ3JleS1kYXJrO1xuICAgIH1cbiAgICAmLWdyZXkge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItZ3JleTtcbiAgICB9XG4gICAgJi1ncmV5LWxpZ2h0IHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLWdyZXktbGlnaHQ7XG4gICAgfVxufSIsIi8vIENvbG9yc1xuXG4kY29sb3ItcHJpbWFyeTE6IHJnYmEoMjcsNDUsNjMsMSk7XG4kY29sb3ItcHJpbWFyeTI6IHJnYmEoNTMsNzAsODgsMSk7XG5cbiRjb2xvci1ncmV5OiByZ2JhKDEwMywgMTAzLCAxMDMsIDEpO1xuJGNvbG9yLWdyZXktZGFyazogcmdiYSg1MiwgNTgsIDY0LCAxKTtcblxuJGNvbG9yLWdyZXktbGlnaHQ6ICNFQkVDRjA7XG5cbiRjb2xvci1zdWNjZXNzOiByZ2JhKDgyLCAyMDksIDE0NSwgMSk7XG4kY29sb3ItZXJyb3I6IHJnYmEoMjM0LCA4NSwgODUsIDEpO1xuXG4vLyBGb250c1xuXG4kdGhpbjogMTAwO1xuJGV4dHJhLWxpZ2h0OiAyMDA7XG4kbGlnaHQ6IDMwMDtcbiRyZWd1bGFyLTQwMDogNDAwO1xuJG1lZGl1bTogNTAwO1xuJHNlbWktYm9sZDogNjAwO1xuJGJvbGQ6IDcwMDtcbiRleHRyYS1ib2xkOiA4MDA7XG4kYmxhY2stOTAwOiA5MDA7IiwiLypcbjBweCAtIDM2MHB4Olx0XHRYUyBQaG9uZVxuMzYwcHggLSA1NzZweDogXHRcdFBob25lXG41NzZweCAtIDc2OHB4OiBcdFx0VGFibGV0IFBvcnRyYWl0XG43NjhweCAtIDk5MnB4Olx0XHRUYWJsZXQgTGFuZHNjYXBlXG45OTJweCAtIDEyMDBweDogXHRkZXNrdG9wXG4xMjAwcHggLSAxOTIwcHg6XHRub3JtYWwgTWVkaWEgcXVlcmllc1xuMTkyMHB4IGFuZCB1cDogIFx0RnVsbCBIRFxuKi9cbi8qXG4kYnJlYWtwb2ludCBhcmd1ZW1lbnQgY2hvaWNlczpcbi0geHMtcGhvbmVcbi0gcGhvbmVcbi0gdGFiLXBvcnRcbi0gdGFiLWxhbmRcbi0gZGVza3RvcFxuLSBmdWxsLWhkXG5cbjFlbSA9IDE2cHhcbiovXG4udGV4dC1wcmltYXJ5MSB7XG4gIGNvbG9yOiAjMWIyZDNmO1xufVxuLnRleHQtZ3JleS1kYXJrIHtcbiAgY29sb3I6ICMzNDNhNDA7XG59XG4udGV4dC1ncmV5IHtcbiAgY29sb3I6ICM2NzY3Njc7XG59XG4udGV4dC1ncmV5LWxpZ2h0IHtcbiAgY29sb3I6ICNFQkVDRjA7XG59XG5cbi5iZy1wcmltYXJ5MSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxYjJkM2Y7XG59XG4uYmctcHJpbWFyeTIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzU0NjU4O1xufVxuLmJnLWdyZXktZGFyayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzNDNhNDA7XG59XG4uYmctZ3JleSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM2NzY3Njc7XG59XG4uYmctZ3JleS1saWdodCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFQkVDRjA7XG59XG5cbmgxIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xuICBsaW5lLWhlaWdodDogMC4xZW07XG4gIG1hcmdpbjogMTBweCAwIDIwcHg7XG59XG5cbmgxIHNwYW4ge1xuICBiYWNrZ3JvdW5kOiAjZWJlY2YwO1xuICBwYWRkaW5nOiAwIDE1cHggMCAwO1xufVxuXG5oNSB7XG4gIG1hcmdpbi1ib3R0b206IDAuNHJlbTtcbiAgbWFyZ2luLXRvcDogMC40cmVtO1xufVxuXG5pbWcge1xuICBtYXgtd2lkdGg6IDEwMCU7XG59XG5cbi5pbmJveF9wZW9wbGUge1xuICBiYWNrZ3JvdW5kOiAjZjhmOGY4IG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XG4gIGZsb2F0OiBsZWZ0O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB3aWR0aDogNDAlO1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjYzRjNGM0O1xufVxuXG4uaW5ib3hfbXNnIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2M0YzRjNDtcbiAgY2xlYXI6IGJvdGg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50b3Bfc3BhYyB7XG4gIG1hcmdpbjogMjBweCAwIDA7XG59XG5cbi5jaGFubmVsX2hlYWRpbmcge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLnNyY2hfYmFyIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgd2lkdGg6IDYwJTtcbn1cblxuLmhlYWRpbmRfc3JjaCB7XG4gIHBhZGRpbmc6IDEwcHggMjlweCAxMHB4IDIwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzRjNGM0O1xufVxuXG4uY2hhbm5lbF9oZWFkaW5nIGg0IHtcbiAgY29sb3I6ICMwNTcyOGY7XG4gIGZvbnQtc2l6ZTogMjFweDtcbiAgbWFyZ2luOiBhdXRvO1xufVxuXG4uc3JjaF9iYXIgaW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2RjZGNkO1xuICBib3JkZXItd2lkdGg6IDAgMCAxcHggMDtcbiAgd2lkdGg6IDgwJTtcbiAgcGFkZGluZzogMnB4IDAgNHB4IDZweDtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLnNyY2hfYmFyIC5pbnB1dC1ncm91cC1hZGRvbiBidXR0b24ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDApIG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XG4gIGJvcmRlcjogbWVkaXVtIG5vbmU7XG4gIHBhZGRpbmc6IDA7XG4gIGNvbG9yOiAjNzA3MDcwO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5zcmNoX2JhciAuaW5wdXQtZ3JvdXAtYWRkb24ge1xuICBtYXJnaW46IDAgMCAwIC0yN3B4O1xufVxuXG4uY2hhdF9pYiBoNSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICM0NjQ2NDY7XG4gIG1hcmdpbjogMCAwIDhweCAwO1xufVxuXG4uY2hhdF9pYiBoNSBzcGFuIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5jaGF0X2liIHAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjOTg5ODk4O1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5jaGF0X2ltZyB7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogMTElO1xufVxuXG4uY2hhdF9pYiB7XG4gIGZsb2F0OiBsZWZ0O1xuICBwYWRkaW5nOiAwIDAgMCAxNXB4O1xuICB3aWR0aDogODglO1xufVxuXG4uY2hhdF9wZW9wbGUge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjbGVhcjogYm90aDtcbn1cblxuLmNoYXRfbGlzdCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYzRjNGM0O1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDE4cHggMTZweCAxMHB4O1xufVxuXG4uaW5ib3hfY2hhdCB7XG4gIGhlaWdodDogNTUwcHg7XG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcbn1cblxuLmFjdGl2ZV9jaGF0IHtcbiAgYmFja2dyb3VuZDogI2ViZWJlYjtcbn1cblxuLmluY29taW5nX21zZ19pbWcge1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIGJhY2tncm91bmQ6ICNmZmViZWI7XG4gIHdpZHRoOiA1MCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuLmluY29taW5nX21zZ19pbWcgaW1nIHtcbiAgd2lkdGg6IDNyZW07XG4gIGhlaWdodDogM3JlbTtcbiAgYWxpZ24tc2VsZjogY2VudGVyO1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuLmluY29taW5nX21zZ19pbWcgLm5hbWUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uaW5jb21pbmdfbXNnX2ltZ19tb2JpbGUge1xuICBiYWNrZ3JvdW5kOiAjZmZlYmViO1xuICB3aWR0aDogNTAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuLmluY29taW5nX21zZ19pbWdfbW9iaWxlIGltZyB7XG4gIHdpZHRoOiAzcmVtO1xuICBoZWlnaHQ6IDNyZW07XG4gIGFsaWduLXNlbGY6IGNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbn1cblxuLnRlYWNoZXJCYWRnZSB7XG4gIHJpZ2h0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGUgIWltcG9ydGFudDtcbiAgdG9wOiAtNXB4ICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgei1pbmRleDogYXV0bztcbn1cblxuLnJlY2VpdmVkX21zZyB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcGFkZGluZzogMCAwIDAgMTBweDtcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcbiAgd2lkdGg6IDkyJTtcbn1cblxuLnJlY2VpdmVkX3dpdGhkX21zZyBwIHtcbiAgYmFja2dyb3VuZDogI2ViZWJlYiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xuICBib3JkZXItcmFkaXVzOiAzcHg7XG4gIGNvbG9yOiAjNjQ2NDY0O1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi50aW1lX2RhdGUge1xuICBjb2xvcjogIzc0NzQ3NDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luOiA4cHggMCAwO1xufVxuXG4ucmVjZWl2ZWRfd2l0aGRfbXNnIHtcbiAgd2lkdGg6IDQ1JTtcbn1cblxuLm1lc2dzIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5zZW50X21zZyBwIHtcbiAgYmFja2dyb3VuZDogIzA1NzI4ZiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xuICBib3JkZXItcmFkaXVzOiAzcHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbWFyZ2luOiAwO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogNXB4IDEwcHggNXB4IDEycHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ub3V0Z29pbmdfbXNnIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luOiAyNnB4IDAgMjZweDtcbn1cblxuLnNlbnRfbXNnIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICB3aWR0aDogNDYlO1xufVxuXG4uaW5wdXRfbXNnX3dyaXRlIGlucHV0IHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwKSBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xuICBib3JkZXI6IG1lZGl1bSBub25lO1xuICBjb2xvcjogIzRjNGM0YztcbiAgZm9udC1zaXplOiAxNXB4O1xuICBtaW4taGVpZ2h0OiA1MHB4O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnR5cGVfbXNnIHtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNjNGM0YzQ7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4ubXNnX3NlbmRfYnRuIHtcbiAgYmFja2dyb3VuZDogIzA1NzI4ZiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xuICBib3JkZXI6IG1lZGl1bSBub25lO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGNvbG9yOiAjZmZmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luOiA1cHg7XG4gIHdpZHRoOiA0MHB4O1xufVxuQG1lZGlhIChtYXgtd2lkdGg6IDY2MHB4KSB7XG4gIC5tc2dfc2VuZF9idG4ge1xuICAgIGxlZnQ6IDg4JTtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDY2MHB4KSB7XG4gIC5tc2dfc2VuZF9idG4ub25lIHtcbiAgICBsZWZ0OiA3OCU7XG4gIH1cbn1cblxuLm1lc3NhZ2luZyB7XG4gIHBhZGRpbmc6IDAgMCA1MHB4IDA7XG59XG5cbi5tc2dfaGlzdG9yeSB7XG4gIGhlaWdodDogNjA1cHg7XG4gIG92ZXJmbG93LXk6IGF1dG87XG4gIHBhZGRpbmctbGVmdDogMTVweDtcbiAgcGFkZGluZy1yaWdodDogMTVweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLm1zZ19tb2JpbGVfaGlzdG9yeSB7XG4gIGhlaWdodDogMTAwJTtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cblxuLm1vYmlsZSB7XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgcGFkZGluZy1yaWdodDogMDtcbn1cbi5tb2JpbGUgLm1zZ19tb2JpbGVfaGlzdG9yeSB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbn1cbi5tb2JpbGUgLnR5cGVfbXNnIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBib3R0b206IDY1cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgei1pbmRleDogMTAwO1xufVxuXG4ubWVzc2FnZSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbn1cblxuLmJhZGdlIHtcbiAgdG9wOiAtMS41cmVtO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59IiwiQGltcG9ydCBcIi4uLy4uLy4uL2Fzc2V0cy9zYXNzL2Jhc2UvbWl4aW5cIjtcbkBpbXBvcnQgXCIuLi8uLi8uLi9hc3NldHMvc2Fzcy9iYXNlL2NvbG9yc1wiO1xuXG5oMSB7XG4gIHdpZHRoOiAxMDAlO1xuICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xuICBsaW5lLWhlaWdodDogMC4xZW07XG4gIG1hcmdpbjogMTBweCAwIDIwcHg7XG59XG5cbmgxIHNwYW4ge1xuICAvLyB6LWluZGV4OiAxMDA7XG4gIGJhY2tncm91bmQ6ICNlYmVjZjA7XG4gIHBhZGRpbmc6IDAgMTVweCAwIDA7XG59XG5cbmg1IHtcbiAgbWFyZ2luLWJvdHRvbTogMC40cmVtO1xuICBtYXJnaW4tdG9wOiAwLjRyZW07XG59XG5cbmltZyB7XG4gIG1heC13aWR0aDogMTAwJTtcbn1cblxuLmluYm94X3Blb3BsZSB7XG4gIGJhY2tncm91bmQ6ICNmOGY4Zjggbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHdpZHRoOiA0MCU7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNjNGM0YzQ7XG59XG5cbi5pbmJveF9tc2cge1xuICBib3JkZXI6IDFweCBzb2xpZCAjYzRjNGM0O1xuICBjbGVhcjogYm90aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnRvcF9zcGFjIHtcbiAgbWFyZ2luOiAyMHB4IDAgMDtcbn1cblxuLmNoYW5uZWxfaGVhZGluZyB7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogNDAlO1xufVxuXG4uc3JjaF9iYXIge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICB3aWR0aDogNjAlO1xufVxuXG4uaGVhZGluZF9zcmNoIHtcbiAgcGFkZGluZzogMTBweCAyOXB4IDEwcHggMjBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjNGM0YzQ7XG59XG5cbi5jaGFubmVsX2hlYWRpbmcgaDQge1xuICBjb2xvcjogIzA1NzI4ZjtcbiAgZm9udC1zaXplOiAyMXB4O1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5zcmNoX2JhciBpbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNjZGNkY2Q7XG4gIGJvcmRlci13aWR0aDogMCAwIDFweCAwO1xuICB3aWR0aDogODAlO1xuICBwYWRkaW5nOiAycHggMCA0cHggNnB4O1xuICBiYWNrZ3JvdW5kOiBub25lO1xufVxuXG4uc3JjaF9iYXIgLmlucHV0LWdyb3VwLWFkZG9uIGJ1dHRvbiB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcbiAgYm9yZGVyOiBtZWRpdW0gbm9uZTtcbiAgcGFkZGluZzogMDtcbiAgY29sb3I6ICM3MDcwNzA7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnNyY2hfYmFyIC5pbnB1dC1ncm91cC1hZGRvbiB7XG4gIG1hcmdpbjogMCAwIDAgLTI3cHg7XG59XG5cbi5jaGF0X2liIGg1IHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogIzQ2NDY0NjtcbiAgbWFyZ2luOiAwIDAgOHB4IDA7XG59XG5cbi5jaGF0X2liIGg1IHNwYW4ge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLmNoYXRfaWIgcCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM5ODk4OTg7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuLmNoYXRfaW1nIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHdpZHRoOiAxMSU7XG59XG5cbi5jaGF0X2liIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHBhZGRpbmc6IDAgMCAwIDE1cHg7XG4gIHdpZHRoOiA4OCU7XG59XG5cbi5jaGF0X3Blb3BsZSB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNsZWFyOiBib3RoO1xufVxuXG4uY2hhdF9saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjNGM0YzQ7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMThweCAxNnB4IDEwcHg7XG59XG5cbi5pbmJveF9jaGF0IHtcbiAgaGVpZ2h0OiA1NTBweDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xufVxuXG4uYWN0aXZlX2NoYXQge1xuICBiYWNrZ3JvdW5kOiAjZWJlYmViO1xufVxuXG4uaW5jb21pbmdfbXNnX2ltZyB7XG4gIC8vIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgLy8gd2lkdGg6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIGJhY2tncm91bmQ6ICNmZmViZWI7XG4gIHdpZHRoOiA1MCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBpbWcge1xuICAgIHdpZHRoOiAzcmVtO1xuICAgIGhlaWdodDogM3JlbTtcbiAgICBhbGlnbi1zZWxmOiBjZW50ZXI7XG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgfVxuICAubmFtZSB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgbWFyZ2luOiAwcHg7XG4gIH1cbn1cblxuLmluY29taW5nX21zZ19pbWdfbW9iaWxlIHtcbiAgLy8gZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAvLyB3aWR0aDogOCU7XG4gIGJhY2tncm91bmQ6ICNmZmViZWI7XG4gIHdpZHRoOiA1MCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG5cbiAgaW1nIHtcbiAgICB3aWR0aDogM3JlbTtcbiAgICBoZWlnaHQ6IDNyZW07XG4gICAgYWxpZ24tc2VsZjogY2VudGVyO1xuICAgIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIH1cbn1cblxuLnRlYWNoZXJCYWRnZSB7XG4gIHJpZ2h0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGUgIWltcG9ydGFudDtcbiAgdG9wOiAtNXB4ICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgei1pbmRleDogYXV0bztcbn1cblxuLnJlY2VpdmVkX21zZyB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcGFkZGluZzogMCAwIDAgMTBweDtcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcbiAgd2lkdGg6IDkyJTtcbiAgLy8gLm5hbWUge1xuICAvLyAgIGZvbnQtc2l6ZTogMTRweDtcbiAgLy8gICBmb250LXdlaWdodDogNjAwO1xuICAvLyAgIG1hcmdpbjogNXB4O1xuICAvLyB9XG59XG5cbi5yZWNlaXZlZF93aXRoZF9tc2cgcCB7XG4gIGJhY2tncm91bmQ6ICNlYmViZWIgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBjb2xvcjogIzY0NjQ2NDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4udGltZV9kYXRlIHtcbiAgY29sb3I6ICM3NDc0NzQ7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXNpemU6IDEycHg7XG4gIG1hcmdpbjogOHB4IDAgMDtcbn1cblxuLnJlY2VpdmVkX3dpdGhkX21zZyB7XG4gIHdpZHRoOiA0NSU7XG59XG5cbi5tZXNncyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uc2VudF9tc2cgcCB7XG4gIGJhY2tncm91bmQ6ICMwNTcyOGYgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbjogMDtcbiAgY29sb3I6ICNmZmY7XG4gIHBhZGRpbmc6IDVweCAxMHB4IDVweCAxMnB4O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLm91dGdvaW5nX21zZyB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIG1hcmdpbjogMjZweCAwIDI2cHg7XG59XG5cbi5zZW50X21zZyB7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IDQ2JTtcbn1cblxuLmlucHV0X21zZ193cml0ZSBpbnB1dCB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcbiAgYm9yZGVyOiBtZWRpdW0gbm9uZTtcbiAgY29sb3I6ICM0YzRjNGM7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWluLWhlaWdodDogNTBweDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi50eXBlX21zZyB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjYzRjNGM0O1xuICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4ubXNnX3NlbmRfYnRuIHtcbiAgYmFja2dyb3VuZDogIzA1NzI4ZiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xuICBib3JkZXI6IG1lZGl1bSBub25lO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGNvbG9yOiAjZmZmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgLy8gaGVpZ2h0OiAzM3B4O1xuICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIC8vIGxlZnQ6IDc5JTtcbiAgLy8gdG9wOiAxMXB4O1xuICBtYXJnaW46IDVweDtcbiAgd2lkdGg6IDQwcHg7XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2NjBweCkge1xuICAgIGxlZnQ6IDg4JTtcbiAgfVxuICAmLm9uZSB7XG4gICAgLy8gbGVmdDogNzQuNSU7XG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDY2MHB4KSB7XG4gICAgICBsZWZ0OiA3OCU7XG4gICAgfVxuICB9XG59XG5cbi5tZXNzYWdpbmcge1xuICBwYWRkaW5nOiAwIDAgNTBweCAwO1xufVxuXG4ubXNnX2hpc3Rvcnkge1xuICBoZWlnaHQ6IDYwNXB4O1xuICBvdmVyZmxvdy15OiBhdXRvO1xuICBwYWRkaW5nLWxlZnQ6IDE1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE1cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5tc2dfbW9iaWxlX2hpc3Rvcnkge1xuICBoZWlnaHQ6IDEwMCU7XG4gIG92ZXJmbG93LXk6IGF1dG87XG59XG5cbi5tb2JpbGUge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIHBhZGRpbmctcmlnaHQ6IDA7XG4gIC5tc2dfbW9iaWxlX2hpc3Rvcnkge1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gIH1cbiAgLnR5cGVfbXNnIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgYm90dG9tOiA2NXB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIHotaW5kZXg6IDEwMDtcbiAgfVxufVxuXG4ubWVzc2FnZSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbn1cblxuLmJhZGdlIHtcbiAgdG9wOiAtMS41cmVtO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4iXX0= */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MessageComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-common-message',
          templateUrl: './message.component.html',
          styleUrls: ['./message.component.scss']
        }]
      }], function () {
        return [];
      }, {
        type: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        isMobileView: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/common/mobile-header/mobile-header.component.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/common/mobile-header/mobile-header.component.ts ***!
    \*****************************************************************/

  /*! exports provided: MobileHeaderComponent */

  /***/
  function srcAppCommonMobileHeaderMobileHeaderComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MobileHeaderComponent", function () {
      return MobileHeaderComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function MobileHeaderComponent_div_11_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "\xA0 ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 25);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h4", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 30);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "p");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "br");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 32);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Acknowlege");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var announcement_r3 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", announcement_r3.msg, " :");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](announcement_r3.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Announcement from : ", announcement_r3.msg, "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Announcement Date : ", announcement_r3.date, " ", announcement_r3.month, "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Description : ", announcement_r3.des, " Change the size of the modal by adding the .modal-sm class for small modals or .modal-lg class for large modals.");
      }
    }

    function MobileHeaderComponent_div_25_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 33);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 34);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 36);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 37);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 38);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h4");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 39);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h4");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\xA0");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "span", 40);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var upcoming_r4 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.msg);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.type);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](upcoming_r4.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Endtime : ", upcoming_r4.endtime, "");
      }
    }

    function MobileHeaderComponent_div_28_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 33);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 34);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 35);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 36);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 37);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 38);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h4");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 39);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h4");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\xA0");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "span", 40);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "b");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var overdue_r5 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r5.date);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r5.month);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r5.msg);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r5.type);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](overdue_r5.des);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" Due : ", overdue_r5.endtime, "");
      }
    }

    var MobileHeaderComponent = /*#__PURE__*/function () {
      function MobileHeaderComponent() {
        _classCallCheck(this, MobileHeaderComponent);

        this.announcements = [{
          date: '8',
          month: 'Jan',
          msg: 'School ',
          des: ' Annual Function'
        }, {
          date: '26',
          month: 'Jan',
          msg: 'School ',
          des: ' Republic Day'
        }, {
          date: '2',
          month: 'Feb',
          msg: 'School ',
          des: ' 25 Anniversary of school'
        }, {
          date: '8',
          month: 'Jan',
          msg: 'School ',
          des: ' Annual Function'
        }];
        this.upcomings = [{
          date: '9',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }, {
          date: '10',
          month: 'Jan',
          msg: 'Marathi ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 2'
        }, {
          date: '12',
          month: 'Jan',
          msg: 'Hindi ',
          type: 'Test',
          endtime: '7:00 pm',
          des: ' Chapter 3'
        }, {
          date: '18',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '10:00 pm',
          des: ' Quadratic Equation'
        }];
        this.overdues = [{
          date: '7',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }, {
          date: '6',
          month: 'Jan',
          msg: 'Science ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 1'
        }, {
          date: '6',
          month: 'Jan',
          msg: 'Marathi ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Assignment 1'
        }, {
          date: '5',
          month: 'Jan',
          msg: 'Math ',
          type: 'Assignment',
          endtime: '7:00 pm',
          des: ' Quadratic Equation'
        }];
      }

      _createClass(MobileHeaderComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "incSize",
        value: function incSize() {
          var x = document.getElementById("p-2");
          x.style.height = "180px", x.style.transition = "1s";
          document.getElementById("btn1").style.display = "none";
          document.getElementById("btn2").style.display = "inline";
        }
      }, {
        key: "decSize",
        value: function decSize() {
          var x = document.getElementById("p-2");
          x.style.height = "65px", x.style.transition = "1s";
          document.getElementById("btn1").style.display = "inline";
          document.getElementById("btn2").style.display = "none";
        }
      }]);

      return MobileHeaderComponent;
    }();

    MobileHeaderComponent.ɵfac = function MobileHeaderComponent_Factory(t) {
      return new (t || MobileHeaderComponent)();
    };

    MobileHeaderComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: MobileHeaderComponent,
      selectors: [["app-mobile-header"]],
      decls: 29,
      vars: 3,
      consts: [[2, "padding-left", "15px", "padding-right", "15px", "padding-top", "1px"], [1, "bg-primary1", "mt-4", "d-flex", "justify-content-between", 2, "height", "30px", "border-radius", "5px"], [2, "margin-top", "4px", "margin-left", "5px", "color", "#ffffff", "padding", "2px"], ["type", "button", "id", "btn1", 1, "btn", 3, "click"], ["height", "20", "src", "../../../assets/img/arrow-down-sign-to-navigate.svg", "alt", "img", 1, "m-2"], ["type", "button", "id", "btn2", 1, "btn", 3, "click"], ["height", "20", "src", "../../../assets/img/up-arrow.svg", "alt", "img", 1, "m-2"], ["id", "p-2", 1, "p-2", 2, "background", "white", "width", "100%", "border-radius", "5px", "height", "66px", "overflow-y", "auto"], [1, "d-flex", "flex-column", 2, "margin", "0px 5px"], [4, "ngFor", "ngForOf"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs", "bg-primary1", "mt-4", 2, "font-size", "16px", "height", "100%", "border-radius", "5px"], [1, "nav-item", 2, "margin-right", "auto", "padding-left", "20px"], ["id", "home-tab", "data-toggle", "tab", "href", "#upcomings", "role", "tab", "aria-controls", "home", "aria-selected", "true", 1, "nav-link", "active"], [1, "nav-item", 2, "padding-right", "20px"], ["id", "profile-tab", "data-toggle", "tab", "href", "#overdue", "role", "tab", "aria-controls", "profile", "aria-selected", "false", 1, "nav-link"], ["id", "myTabContent", 1, "tab-content", 2, "background-color", "#ffffff", "padding-top", "5px"], ["id", "upcomings", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [1, "scrollmenu"], ["style", "padding: 0%; padding-left: 10px; padding-bottom: 10px;", 4, "ngFor", "ngForOf"], ["id", "overdue", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "button", "data-toggle", "modal", "data-target", "#myModal", 1, "btn", "btn-block", "d-flex", "m-2", "card", "flex-row", "card-desing", 2, "border-radius", "5px"], [1, "d-flex", "flex-column", "annoucement-date-box", 2, "border-radius", "5px"], [1, "announcment-card-body", "d-flex", "flex-row"], [2, "font-weight", "bold", "font-size", "17px"], [2, "padding-top", "3px"], ["id", "myModal", "role", "dialog", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-sm", 2, "border-radius", "10px", "margin-top", "100px"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], [1, "modal-body"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-default"], [2, "padding", "0%", "padding-left", "10px", "padding-bottom", "10px"], ["type", "button", 1, "btn", "card", "card-body", "text-left", 2, "background", "#f6f4f4", "width", "145px", "height", "120px", "box-shadow", "1px 3px 5px  rgb(129, 128, 128)", "border-radius", "5px"], [1, "d-flex", 2, "padding-left", "0%", "padding-top", "0%"], [1, "d-flex", "flex-column", "upcoming-date-box", 2, "height", "40px", "padding-top", "5px"], [2, "font-style", "ubuntu", "font-size", "12px"], [1, "d-flex", "flex-column", "upcoming-type-box", 2, "height", "40px", "padding-top", "5px"], [2, "font-size", "11px", "color", "#757575"], [2, "color", "#757575"]],
      template: function MobileHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "h2", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Announcement");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MobileHeaderComponent_Template_button_click_5_listener() {
            return ctx.incSize();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MobileHeaderComponent_Template_button_click_7_listener() {
            return ctx.decSize();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, MobileHeaderComponent_div_11_Template, 30, 9, "div", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "ul", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "li", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "a", 12);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "b");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "Upcomings");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "li", 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "b");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Overdue");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](25, MobileHeaderComponent_div_25_Template, 25, 6, "div", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](28, MobileHeaderComponent_div_28_Template, 25, 6, "div", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.announcements);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.upcomings);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.overdues);
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"]],
      styles: [".text-primary1[_ngcontent-%COMP%] {\n  color: #1b2d3f;\n}\n.text-grey-dark[_ngcontent-%COMP%] {\n  color: #343a40;\n}\n.text-grey[_ngcontent-%COMP%] {\n  color: #676767;\n}\n.text-grey-light[_ngcontent-%COMP%] {\n  color: #EBECF0;\n}\n.bg-primary1[_ngcontent-%COMP%] {\n  background-color: #1b2d3f;\n}\n.bg-primary2[_ngcontent-%COMP%] {\n  background-color: #354658;\n}\n.bg-grey-dark[_ngcontent-%COMP%] {\n  background-color: #343a40;\n}\n.bg-grey[_ngcontent-%COMP%] {\n  background-color: #676767;\n}\n.bg-grey-light[_ngcontent-%COMP%] {\n  background-color: #EBECF0;\n}\ndiv.scrollmenu[_ngcontent-%COMP%] {\n  overflow: auto;\n  white-space: nowrap;\n}\ndiv.scrollmenu[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-align: center;\n  padding: 14px;\n  text-decoration: none;\n}\n.nav-link[_ngcontent-%COMP%] {\n  color: #c4c4c4;\n  border: none;\n}\n.nav-link.active[_ngcontent-%COMP%] {\n  background: #1B2D3F;\n  color: #ffffff;\n  border-bottom: 4px solid #28BAA2;\n}\n.card-fixed[_ngcontent-%COMP%] {\n  height: 100%;\n  min-height: 100px;\n  max-height: 100px;\n  width: 100%;\n  max-width: 100px;\n  min-width: 100px;\n  margin-right: 2rem;\n}\n\n.card-desing[_ngcontent-%COMP%] {\n  background: #354658;\n  height: 50px;\n  width: 100%;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25), 0px 2px 4px rgba(0, 0, 0, 0.14), 0px 3px 4px rgba(0, 0, 0, 0.12), 0px -2px 5px rgba(0, 0, 0, 0.2);\n}\n.announcment-card-body[_ngcontent-%COMP%] {\n  margin-top: auto;\n  margin-bottom: auto;\n  text-align: left;\n  padding-left: 10px;\n  width: 100%;\n  font-size: 14px;\n  color: white;\n}\n.annoucement-date-box[_ngcontent-%COMP%] {\n  background-color: #28BAA2;\n  font-size: 10px;\n  text-align: center;\n  padding: 5px;\n  padding-left: 12px;\n  padding-right: 12px;\n  color: white;\n}\n.upcoming-date-box[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  font-size: 10px;\n  text-align: center;\n  padding: 0px;\n  padding-left: 0px;\n  padding-right: 0px;\n  color: black;\n  box-shadow: 1px 3px 5px #818080;\n}\n.upcoming-type-box[_ngcontent-%COMP%] {\n  background-color: #f6f4f4;\n  font-size: 10px;\n  text-align: center;\n  padding: 0px;\n  padding-left: 0px;\n  padding-right: 0px;\n  color: black;\n}\n#btn2[_ngcontent-%COMP%] {\n  display: none;\n}\n[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 5px;\n}\n.scrollmenu[_ngcontent-%COMP%]::-webkit-scrollbar {\n  height: 5px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  box-shadow: inset 0 0 5px grey;\n  border-radius: 10px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  background: #354658;\n  border-radius: 10px;\n}\n\n[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover {\n  background: #8d8d8d;\n}\n.modal-content[_ngcontent-%COMP%] {\n  border-radius: 12px;\n}\n.modal-header[_ngcontent-%COMP%] {\n  text-align: center;\n  background-color: #1B2D3F;\n  color: #ffffff;\n  border-radius: 10px 10px 0px 0px;\n}\n.modal-title[_ngcontent-%COMP%] {\n  margin: auto;\n}\n.modal-footer[_ngcontent-%COMP%] {\n  border: none;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  text-align: center;\n  background-color: #354658;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL21vYmlsZS1oZWFkZXIvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfbWl4aW4uc2NzcyIsInNyYy9hcHAvY29tbW9uL21vYmlsZS1oZWFkZXIvQzpcXFVzZXJzXFxQcmF2aW5cXEZyb250LWVuZC1tYWluL3NyY1xcYXNzZXRzXFxzYXNzXFxiYXNlXFxfY29sb3JzLnNjc3MiLCJzcmMvYXBwL2NvbW1vbi9tb2JpbGUtaGVhZGVyL0M6XFxVc2Vyc1xcUHJhdmluXFxGcm9udC1lbmQtbWFpbi9zcmNcXGFzc2V0c1xcc2Fzc1xcYmFzZVxcX3ZhcmlhYmxlcy5zY3NzIiwic3JjL2FwcC9jb21tb24vbW9iaWxlLWhlYWRlci9tb2JpbGUtaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21tb24vbW9iaWxlLWhlYWRlci9DOlxcVXNlcnNcXFByYXZpblxcRnJvbnQtZW5kLW1haW4vc3JjXFxhcHBcXGNvbW1vblxcbW9iaWxlLWhlYWRlclxcbW9iaWxlLWhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTs7Ozs7Ozs7Q0FBQTtBQVdBOzs7Ozs7Ozs7O0NBQUE7QUNYSTtFQUNJLGNDRlM7QUNvQmpCO0FGaEJJO0VBQ0ksY0NEVTtBQ21CbEI7QUZoQkk7RUFDSSxjQ0xLO0FDdUJiO0FGaEJJO0VBQ0ksY0NMVztBQ3VCbkI7QUZaSTtFQUNJLHlCQ2xCUztBQ2lDakI7QUZiSTtFQUNJLHlCQ3BCUztBQ21DakI7QUZiSTtFQUNJLHlCQ3BCVTtBQ21DbEI7QUZiSTtFQUNJLHlCQ3hCSztBQ3VDYjtBRmJJO0VBQ0kseUJDeEJXO0FDdUNuQjtBQzVDQTtFQUVJLGNBQUE7RUFDQSxtQkFBQTtBRDhDSjtBQzNDRTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7QUQ4Q0o7QUMzQ0E7RUFDRSxjQUFBO0VBQ0EsWUFBQTtBRDhDRjtBQzNDQTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0FEOENGO0FDMUNBO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FENkNKO0FDOUJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBQUE7QUFvQkE7RUFDRSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsOElBQUE7QURpQ0Y7QUM5QkE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBRGlDRjtBQy9CQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FEa0NGO0FDaENBO0VBQ0UseUJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtBRG1DRjtBQ2pDQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FEb0NGO0FDbENBO0VBQ0UsYUFBQTtBRHFDRjtBQ25DQTtFQUNFLFVBQUE7QURzQ0Y7QUNuQ0E7RUFDRSxXQUFBO0FEc0NGO0FDbkNBLFVBQUE7QUFDQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QURzQ0Y7QUNuQ0EsV0FBQTtBQUNBO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtBRHNDRjtBQ25DQSxvQkFBQTtBQUNBO0VBQ0UsbUJBQUE7QURzQ0Y7QUNwQ0E7RUFDRSxtQkFBQTtBRHVDRjtBQ3JDQTtFQUNJLGtCQUFBO0VBQW9CLHlCQUFBO0VBQTJCLGNBQUE7RUFBZ0IsZ0NBQUE7QUQyQ25FO0FDekNBO0VBQ0UsWUFBQTtBRDRDRjtBQzFDQTtFQUNFLFlBQUE7QUQ2Q0Y7QUMzQ0E7RUFDRSxrQkFBQTtFQUFvQix5QkFBQTtFQUEyQixjQUFBO0FEZ0RqRCIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi9tb2JpbGUtaGVhZGVyL21vYmlsZS1oZWFkZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi8vIE1FRElBIFFVRVJZIE1BTkFHRVJcblxuLypcbjBweCAtIDM2MHB4Olx0XHRYUyBQaG9uZVxuMzYwcHggLSA1NzZweDogXHRcdFBob25lXG41NzZweCAtIDc2OHB4OiBcdFx0VGFibGV0IFBvcnRyYWl0XG43NjhweCAtIDk5MnB4Olx0XHRUYWJsZXQgTGFuZHNjYXBlXG45OTJweCAtIDEyMDBweDogXHRkZXNrdG9wXG4xMjAwcHggLSAxOTIwcHg6XHRub3JtYWwgTWVkaWEgcXVlcmllc1xuMTkyMHB4IGFuZCB1cDogIFx0RnVsbCBIRFxuKi9cblxuXG4vKlxuJGJyZWFrcG9pbnQgYXJndWVtZW50IGNob2ljZXM6XG4tIHhzLXBob25lXG4tIHBob25lXG4tIHRhYi1wb3J0XG4tIHRhYi1sYW5kXG4tIGRlc2t0b3Bcbi0gZnVsbC1oZFxuXG4xZW0gPSAxNnB4XG4qL1xuXG5AbWl4aW4gcmVzcG9uZE1heCgkYnJlYWtwb2ludCkge1xuXHRAaWYgJGJyZWFrcG9pbnQgPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWF4LXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnQgPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtYXgtd2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1heC13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuICB9XG4gIEBpZiAkYnJlYWtwb2ludCA9PSBoZC1kZXNrdG9wIHtcbiAgICBAbWVkaWEgKG1heC13aWR0aDogOTBlbSkgeyBAY29udGVudCB9OyAvLzE0NDBweFxuICB9XG5cdEBpZiAkYnJlYWtwb2ludCA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5AbWl4aW4gcmVzcG9uZE1pbigkYnJlYWtwb2ludG1pbikge1xuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0geHMtcGhvbmUge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiAyMi41ZW0pIHsgQGNvbnRlbnQgfTsgLy8zNjBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBzbS1waG9uZSB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDM2ZW0pIHsgQGNvbnRlbnQgfTsgLy81NzZweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBtZC10YWIge1xuXHRcdEBtZWRpYSAobWluLXdpZHRoOiA0OGVtKSB7IEBjb250ZW50IH07IC8vNzY4cHhcblx0fVxuXHRAaWYgJGJyZWFrcG9pbnRtaW4gPT0gbGctZGVza3RvcCB7XG5cdFx0QG1lZGlhIChtaW4td2lkdGg6IDYyZW0pIHsgQGNvbnRlbnQgfTsgLy85OTJweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSB4bC1kZXNrdG9wIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogNzVlbSkgeyBAY29udGVudCB9OyAvLzEyMDBweFxuXHR9XG5cdEBpZiAkYnJlYWtwb2ludG1pbiA9PSBmdWxsLWhkIHtcblx0XHRAbWVkaWEgKG1pbi13aWR0aDogMTIwZW0pIHsgQGNvbnRlbnQgfTsgLy8xOTIwcHhcblx0fVxufVxuXG5cblxuXG4kcmVtLWJhc2VsaW5lOiAxNnB4ICFkZWZhdWx0O1xuJHJlbS1mYWxsYmFjazogZmFsc2UgIWRlZmF1bHQ7XG4kcmVtLXB4LW9ubHk6IGZhbHNlICFkZWZhdWx0O1xuXG5AZnVuY3Rpb24gcmVtLXNlcGFyYXRvcigkbGlzdCwgJHNlcGFyYXRvcjogZmFsc2UpIHtcbiAgQGlmICRzZXBhcmF0b3IgPT0gXCJjb21tYVwiIG9yICRzZXBhcmF0b3IgPT0gXCJzcGFjZVwiIHtcbiAgICBAcmV0dXJuIGFwcGVuZCgkbGlzdCwgbnVsbCwgJHNlcGFyYXRvcik7XG4gIH0gXG4gIFxuICBAaWYgZnVuY3Rpb24tZXhpc3RzKFwibGlzdC1zZXBhcmF0b3JcIikgPT0gdHJ1ZSB7XG4gICAgQHJldHVybiBsaXN0LXNlcGFyYXRvcigkbGlzdCk7XG4gIH1cblxuICAvLyBsaXN0LXNlcGFyYXRvciBwb2x5ZmlsbCBieSBIdWdvIEdpcmF1ZGVsIChodHRwczovL3Nhc3MtY29tcGF0aWJpbGl0eS5naXRodWIuaW8vI2xpc3Rfc2VwYXJhdG9yX2Z1bmN0aW9uKVxuICAkdGVzdC1saXN0OiAoKTtcbiAgQGVhY2ggJGl0ZW0gaW4gJGxpc3Qge1xuICAgICR0ZXN0LWxpc3Q6IGFwcGVuZCgkdGVzdC1saXN0LCAkaXRlbSwgc3BhY2UpO1xuICB9XG5cbiAgQHJldHVybiBpZigkdGVzdC1saXN0ID09ICRsaXN0LCBzcGFjZSwgY29tbWEpO1xufVxuXG5AbWl4aW4gcmVtLWJhc2VsaW5lKCR6b29tOiAxMDAlKSB7XG4gIGZvbnQtc2l6ZTogJHpvb20gLyAxNnB4ICogJHJlbS1iYXNlbGluZTtcbn1cblxuQGZ1bmN0aW9uIHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlcy4uLikge1xuICAkcmVzdWx0OiAoKTtcbiAgJHNlcGFyYXRvcjogcmVtLXNlcGFyYXRvcigkdmFsdWVzKTtcbiAgXG4gIEBlYWNoICR2YWx1ZSBpbiAkdmFsdWVzIHtcbiAgICBAaWYgdHlwZS1vZigkdmFsdWUpID09IFwibnVtYmVyXCIgYW5kIHVuaXQoJHZhbHVlKSA9PSBcInJlbVwiIGFuZCAkdG8gPT0gXCJweFwiIHtcbiAgICAgICRyZXN1bHQ6IGFwcGVuZCgkcmVzdWx0LCAkdmFsdWUgLyAxcmVtICogJHJlbS1iYXNlbGluZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSBpZiB0eXBlLW9mKCR2YWx1ZSkgPT0gXCJudW1iZXJcIiBhbmQgdW5pdCgkdmFsdWUpID09IFwicHhcIiBhbmQgJHRvID09IFwicmVtXCIge1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSAvICRyZW0tYmFzZWxpbmUgKiAxcmVtLCAkc2VwYXJhdG9yKTtcbiAgICB9IEBlbHNlIGlmIHR5cGUtb2YoJHZhbHVlKSA9PSBcImxpc3RcIiB7XG4gICAgICAkdmFsdWUtc2VwYXJhdG9yOiByZW0tc2VwYXJhdG9yKCR2YWx1ZSk7XG4gICAgICAkdmFsdWU6IHJlbS1jb252ZXJ0KCR0bywgJHZhbHVlLi4uKTtcbiAgICAgICR2YWx1ZTogcmVtLXNlcGFyYXRvcigkdmFsdWUsICR2YWx1ZS1zZXBhcmF0b3IpO1xuICAgICAgJHJlc3VsdDogYXBwZW5kKCRyZXN1bHQsICR2YWx1ZSwgJHNlcGFyYXRvcik7XG4gICAgfSBAZWxzZSB7XG4gICAgICAkcmVzdWx0OiBhcHBlbmQoJHJlc3VsdCwgJHZhbHVlLCAkc2VwYXJhdG9yKTtcbiAgICB9XG4gIH1cblxuICBAcmV0dXJuIGlmKGxlbmd0aCgkcmVzdWx0KSA9PSAxLCBudGgoJHJlc3VsdCwgMSksICRyZXN1bHQpO1xufVxuXG5AZnVuY3Rpb24gcmVtKCR2YWx1ZXMuLi4pIHtcbiAgQGlmICRyZW0tcHgtb25seSB7XG4gICAgQHJldHVybiByZW0tY29udmVydChweCwgJHZhbHVlcy4uLik7XG4gIH0gQGVsc2Uge1xuICAgIEByZXR1cm4gcmVtLWNvbnZlcnQocmVtLCAkdmFsdWVzLi4uKTtcbiAgfVxufVxuXG5AbWl4aW4gcmVtKCRwcm9wZXJ0aWVzLCAkdmFsdWVzLi4uKSB7XG4gIEBpZiB0eXBlLW9mKCRwcm9wZXJ0aWVzKSA9PSBcIm1hcFwiIHtcbiAgICBAZWFjaCAkcHJvcGVydHkgaW4gbWFwLWtleXMoJHByb3BlcnRpZXMpIHtcbiAgICAgIEBpbmNsdWRlIHJlbSgkcHJvcGVydHksIG1hcC1nZXQoJHByb3BlcnRpZXMsICRwcm9wZXJ0eSkpO1xuICAgIH1cbiAgfSBAZWxzZSB7XG4gICAgQGVhY2ggJHByb3BlcnR5IGluICRwcm9wZXJ0aWVzIHtcbiAgICAgIEBpZiAkcmVtLWZhbGxiYWNrIG9yICRyZW0tcHgtb25seSB7XG4gICAgICAgICN7JHByb3BlcnR5fTogcmVtLWNvbnZlcnQocHgsICR2YWx1ZXMuLi4pO1xuICAgICAgfVxuICAgICAgQGlmIG5vdCAkcmVtLXB4LW9ubHkge1xuICAgICAgICAjeyRwcm9wZXJ0eX06IHJlbS1jb252ZXJ0KHJlbSwgJHZhbHVlcy4uLik7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cblxuQG1peGluIGNvbnRlbnQtY2VudGVyIHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHRsZWZ0OiA1MCU7XG5cdHRvcDogNTAlO1xuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSkgdHJhbnNsYXRlWCgtNTAlKTtcbn0iLCJAaW1wb3J0IFwiLi4vYmFzZS92YXJpYWJsZXNcIjtcblxuLnRleHQge1xuICAgICYtcHJpbWFyeTEge1xuICAgICAgICBjb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1kYXJrO1xuICAgIH1cbiAgICAmLWdyZXkge1xuICAgICAgICBjb2xvcjogJGNvbG9yLWdyZXk7XG4gICAgfVxuICAgICYtZ3JleS1saWdodCB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG4gICBcbn1cblxuLmJnIHtcbiAgICAmLXByaW1hcnkxIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkxO1xuICAgIH1cbiAgICAmLXByaW1hcnkyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXByaW1hcnkyO1xuICAgIH1cbiAgICAmLWdyZXktZGFyayB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5LWRhcms7XG4gICAgfVxuICAgICYtZ3JleSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1ncmV5O1xuICAgIH1cbiAgICAmLWdyZXktbGlnaHQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItZ3JleS1saWdodDtcbiAgICB9XG59IiwiLy8gQ29sb3JzXG5cbiRjb2xvci1wcmltYXJ5MTogcmdiYSgyNyw0NSw2MywxKTtcbiRjb2xvci1wcmltYXJ5MjogcmdiYSg1Myw3MCw4OCwxKTtcblxuJGNvbG9yLWdyZXk6IHJnYmEoMTAzLCAxMDMsIDEwMywgMSk7XG4kY29sb3ItZ3JleS1kYXJrOiByZ2JhKDUyLCA1OCwgNjQsIDEpO1xuXG4kY29sb3ItZ3JleS1saWdodDogI0VCRUNGMDtcblxuJGNvbG9yLXN1Y2Nlc3M6IHJnYmEoODIsIDIwOSwgMTQ1LCAxKTtcbiRjb2xvci1lcnJvcjogcmdiYSgyMzQsIDg1LCA4NSwgMSk7XG5cbi8vIEZvbnRzXG5cbiR0aGluOiAxMDA7XG4kZXh0cmEtbGlnaHQ6IDIwMDtcbiRsaWdodDogMzAwO1xuJHJlZ3VsYXItNDAwOiA0MDA7XG4kbWVkaXVtOiA1MDA7XG4kc2VtaS1ib2xkOiA2MDA7XG4kYm9sZDogNzAwO1xuJGV4dHJhLWJvbGQ6IDgwMDtcbiRibGFjay05MDA6IDkwMDsiLCIvKlxuMHB4IC0gMzYwcHg6XHRcdFhTIFBob25lXG4zNjBweCAtIDU3NnB4OiBcdFx0UGhvbmVcbjU3NnB4IC0gNzY4cHg6IFx0XHRUYWJsZXQgUG9ydHJhaXRcbjc2OHB4IC0gOTkycHg6XHRcdFRhYmxldCBMYW5kc2NhcGVcbjk5MnB4IC0gMTIwMHB4OiBcdGRlc2t0b3BcbjEyMDBweCAtIDE5MjBweDpcdG5vcm1hbCBNZWRpYSBxdWVyaWVzXG4xOTIwcHggYW5kIHVwOiAgXHRGdWxsIEhEXG4qL1xuLypcbiRicmVha3BvaW50IGFyZ3VlbWVudCBjaG9pY2VzOlxuLSB4cy1waG9uZVxuLSBwaG9uZVxuLSB0YWItcG9ydFxuLSB0YWItbGFuZFxuLSBkZXNrdG9wXG4tIGZ1bGwtaGRcblxuMWVtID0gMTZweFxuKi9cbi50ZXh0LXByaW1hcnkxIHtcbiAgY29sb3I6ICMxYjJkM2Y7XG59XG4udGV4dC1ncmV5LWRhcmsge1xuICBjb2xvcjogIzM0M2E0MDtcbn1cbi50ZXh0LWdyZXkge1xuICBjb2xvcjogIzY3Njc2Nztcbn1cbi50ZXh0LWdyZXktbGlnaHQge1xuICBjb2xvcjogI0VCRUNGMDtcbn1cblxuLmJnLXByaW1hcnkxIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFiMmQzZjtcbn1cbi5iZy1wcmltYXJ5MiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzNTQ2NTg7XG59XG4uYmctZ3JleS1kYXJrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM0M2E0MDtcbn1cbi5iZy1ncmV5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY3Njc2Nztcbn1cbi5iZy1ncmV5LWxpZ2h0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0VCRUNGMDtcbn1cblxuZGl2LnNjcm9sbG1lbnUge1xuICBvdmVyZmxvdzogYXV0bztcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cblxuZGl2LnNjcm9sbG1lbnUgZGl2IHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDE0cHg7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuLm5hdi1saW5rIHtcbiAgY29sb3I6ICNjNGM0YzQ7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLm5hdi1saW5rLmFjdGl2ZSB7XG4gIGJhY2tncm91bmQ6ICMxQjJEM0Y7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItYm90dG9tOiA0cHggc29saWQgIzI4QkFBMjtcbn1cblxuLmNhcmQtZml4ZWQge1xuICBoZWlnaHQ6IDEwMCU7XG4gIG1pbi1oZWlnaHQ6IDEwMHB4O1xuICBtYXgtaGVpZ2h0OiAxMDBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIG1heC13aWR0aDogMTAwcHg7XG4gIG1pbi13aWR0aDogMTAwcHg7XG4gIG1hcmdpbi1yaWdodDogMnJlbTtcbn1cblxuLyouYW5ub3VuY21lbnQtY2FyZC1ib2R5IHtcbiAgbWFyZ2luLXRvcDogYXV0bztcbiAgbWFyZ2luLWJvdHRvbTogYXV0bztcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuLmFubm91Y2VtZW50LWRhdGUtYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI4QkFBMjtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uY2FyZC1kZXNpbmcge1xuICBiYWNrZ3JvdW5kOiAjMzU0NjU4O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGJveC1zaGFkb3c6IDBweCA0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yNSksIDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xNCksIDBweCAzcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xMiksIDBweCAtMnB4IDVweCByZ2JhKDAsIDAsIDAsIDAuMik7XG59Ki9cbi5jYXJkLWRlc2luZyB7XG4gIGJhY2tncm91bmQ6ICMzNTQ2NTg7XG4gIGhlaWdodDogNTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaGFkb3c6IDBweCA0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yNSksIDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xNCksIDBweCAzcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xMiksIDBweCAtMnB4IDVweCByZ2JhKDAsIDAsIDAsIDAuMik7XG59XG5cbi5hbm5vdW5jbWVudC1jYXJkLWJvZHkge1xuICBtYXJnaW4tdG9wOiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmFubm91Y2VtZW50LWRhdGUtYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI4QkFBMjtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbiAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi51cGNvbWluZy1kYXRlLWJveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAwcHg7XG4gIHBhZGRpbmctbGVmdDogMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAwcHg7XG4gIGNvbG9yOiBibGFjaztcbiAgYm94LXNoYWRvdzogMXB4IDNweCA1cHggIzgxODA4MDtcbn1cblxuLnVwY29taW5nLXR5cGUtYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y2ZjRmNDtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDBweDtcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4jYnRuMiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbjo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICB3aWR0aDogNXB4O1xufVxuXG4uc2Nyb2xsbWVudTo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBoZWlnaHQ6IDVweDtcbn1cblxuLyogVHJhY2sgKi9cbjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xuICBib3gtc2hhZG93OiBpbnNldCAwIDAgNXB4IGdyZXk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi8qIEhhbmRsZSAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XG4gIGJhY2tncm91bmQ6ICMzNTQ2NTg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi8qIEhhbmRsZSBvbiBob3ZlciAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICM4ZDhkOGQ7XG59XG5cbi5tb2RhbC1jb250ZW50IHtcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcbn1cblxuLm1vZGFsLWhlYWRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFCMkQzRjtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMHB4O1xufVxuXG4ubW9kYWwtdGl0bGUge1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5tb2RhbC1mb290ZXIge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5tb2RhbC1mb290ZXIgLmJ0biB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM1NDY1ODtcbiAgY29sb3I6ICNmZmZmZmY7XG59IiwiQGltcG9ydCBcIi4uLy4uLy4uL2Fzc2V0cy9zYXNzL2Jhc2UvbWl4aW5cIjtcbkBpbXBvcnQgXCIuLi8uLi8uLi9hc3NldHMvc2Fzcy9iYXNlL2NvbG9yc1wiO1xuXG5kaXYuc2Nyb2xsbWVudSB7XG4gICAgLy9iYWNrZ3JvdW5kLWNvbG9yOiAjMzMzO1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIH1cbiAgXG4gIGRpdi5zY3JvbGxtZW51IGRpdiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAxNHB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgfVxuXG4ubmF2LWxpbmsge1xuICBjb2xvcjogI2M0YzRjNDtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4ubmF2LWxpbmsuYWN0aXZlIHtcbiAgYmFja2dyb3VuZDogIzFCMkQzRjtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1ib3R0b206IDRweCBzb2xpZCAjMjhCQUEyO1xufVxuXG5cbi5jYXJkLWZpeGVkIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWluLWhlaWdodDogMTAwcHg7XG4gICAgbWF4LWhlaWdodDogMTAwcHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWF4LXdpZHRoOiAxMDBweDtcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMnJlbTtcbn1cblxuLy8gLmFubm91bmNtZW50LWNhcmQtYm9keSB7XG4vLyAgICAgbWFyZ2luLXRvcDogYXV0bztcbi8vICAgICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuLy8gICAgIHdpZHRoOiAxMDAlO1xuLy8gICAgIGZvbnQtc2l6ZTogMTVweDtcbi8vIH1cbi8vIC5hbm5vdWNlbWVudC1kYXRlLWJveCB7XG4vLyAgICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmVlbjtcbi8vICAgICBmb250LXNpemU6IDEycHg7XG4vLyAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuLy8gICAgIHBhZGRpbmc6IDdweDtcbi8vIH1cbi8qLmFubm91bmNtZW50LWNhcmQtYm9keSB7XG4gIG1hcmdpbi10b3A6IGF1dG87XG4gIG1hcmdpbi1ib3R0b206IGF1dG87XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi5hbm5vdWNlbWVudC1kYXRlLWJveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyOEJBQTI7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA1cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmNhcmQtZGVzaW5nIHtcbiAgYmFja2dyb3VuZDogIzM1NDY1ODtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpLCAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTQpLCAwcHggM3B4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTIpLCAwcHggLTJweCA1cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufSovXG4uY2FyZC1kZXNpbmcge1xuICBiYWNrZ3JvdW5kOiAjMzU0NjU4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpLCAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTQpLCAwcHggM3B4IDRweCByZ2JhKDAsIDAsIDAsIDAuMTIpLCAwcHggLTJweCA1cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufVxuXG4uYW5ub3VuY21lbnQtY2FyZC1ib2R5IHtcbiAgbWFyZ2luLXRvcDogYXV0bztcbiAgbWFyZ2luLWJvdHRvbTogYXV0bztcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB3aWR0aDogMTAwJTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogd2hpdGU7XG59XG4uYW5ub3VjZW1lbnQtZGF0ZS1ib3gge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjhCQUEyO1xuICBmb250LXNpemU6IDEwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDEycHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEycHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi51cGNvbWluZy1kYXRlLWJveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAwcHg7XG4gIHBhZGRpbmctbGVmdDogMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAwcHg7XG4gIGNvbG9yOiBibGFjaztcbiAgYm94LXNoYWRvdzogMXB4IDNweCA1cHggIHJnYigxMjksIDEyOCwgMTI4KTtcbn1cbi51cGNvbWluZy10eXBlLWJveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNmY0ZjQ7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAwcHg7XG4gIHBhZGRpbmctbGVmdDogMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAwcHg7XG4gIGNvbG9yOiBibGFjaztcbn1cbiNidG4ye1xuICBkaXNwbGF5OiBub25lO1xufVxuOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIHdpZHRoOiA1cHg7XG59XG5cbi5zY3JvbGxtZW51Ojotd2Via2l0LXNjcm9sbGJhciB7XG4gIGhlaWdodDogNXB4O1xuXG59XG4vKiBUcmFjayAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gIGJveC1zaGFkb3c6IGluc2V0IDAgMCA1cHggZ3JleTsgXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4gXG4vKiBIYW5kbGUgKi9cbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICBiYWNrZ3JvdW5kOiAjMzU0NjU4OyBcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLyogSGFuZGxlIG9uIGhvdmVyICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzhkOGQ4ZDtcbn1cbi5tb2RhbC1jb250ZW50e1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xufVxuLm1vZGFsLWhlYWRlcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IGJhY2tncm91bmQtY29sb3I6ICMxQjJEM0Y7IGNvbG9yOiAjZmZmZmZmOyBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgfVxuLm1vZGFsLXRpdGxle1xuICBtYXJnaW46IGF1dG87XG59XG4ubW9kYWwtZm9vdGVye1xuICBib3JkZXI6IG5vbmU7XG59XG4ubW9kYWwtZm9vdGVyIC5idG57XG4gIHRleHQtYWxpZ246IGNlbnRlcjsgYmFja2dyb3VuZC1jb2xvcjogIzM1NDY1ODsgY29sb3I6ICNmZmZmZmY7XG59Il19 */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MobileHeaderComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-mobile-header',
          templateUrl: './mobile-header.component.html',
          styleUrls: ['./mobile-header.component.scss']
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  }
}]);
//# sourceMappingURL=default~student-student-module~teacher-teacher-module-es5.js.map